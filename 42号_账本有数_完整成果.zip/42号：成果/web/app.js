/* 账本有数 · 前端逻辑
 * 数据来源：window.T5DATA（由 tools/build_web_data.py 从 out/*.json 生成）
 * 全部计算在浏览器内完成，不发起任何网络请求。 */
(function () {
  'use strict';

  var DATA = window.T5DATA || {};
  var CLEAN = DATA.clean;
  if (!CLEAN) {
    document.body.innerHTML = '<p style="padding:48px;font-family:sans-serif">data.js 未生成或损坏，请先运行 <code>python tools/build_web_data.py</code>。</p>';
    return;
  }

  /* ============ 常量 ============ */
  /* 演示基准日＝真实今天（用本地日期，避免 UTC 偏移），
     否则现场录入“昨天”会落到去年。离线批次结果里的 anchor_date 仅用于展示历史数据。 */
  var ANCHOR = ymd(new Date());
  var ANCHOR_DATE = new Date(ANCHOR + 'T12:00:00');

  var COLORS = {
    '餐饮': '#e8743b', '居住': '#4f7cff', '交通': '#16a085', '通讯': '#2f9bd6',
    '购物': '#e0a30a', '衣着': '#d4599a', '学习': '#6c5ce7', '娱乐': '#9b59b6',
    '医疗': '#e74c3c', '其他': '#8b98a0',
    '工资收入': '#1f9d55', '兼职收入': '#48b96f', '理财收益': '#7ac943', '红包转账': '#b4d97a'
  };

  /* 规则表由 tools/build_web_data.py 从 分类规则关键词表.csv 导出，前端不再手写一份 */
  var RULES = (DATA.rules && DATA.rules.expense && DATA.rules.income)
    ? DATA.rules
    : { expense: [], income: [], fallback: { '支出': '其他', '收入': '工资收入' } };
  var EXPENSE_RULES = RULES.expense;
  var INCOME_RULES = RULES.income;
  var INCOME_WORDS = ['收到', '到账', '入账', '工资', '尾款', '稿费', '收益', '兼职', '退款', '赚', '提现'];
  var SPEND_WORDS = ['给', '买', '交', '充', '花', '包', '打车', '吃', '付'];

  var state = {
    ds: CLEAN.datasets[0].id,
    month: '',
    tab: 'overview',
    trendMode: 'expense',
    filters: { q: '', type: '', month: '', cat: '' },
    charts: {},
    manual: {},
    overrides: {},
    budgetOverride: {},
    batch: null,
    uid: 0
  };

  /* ============ 小工具 ============ */
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function num(v) { var n = Number(v); return isFinite(n) ? n : 0; }
  function r2(v) { return Math.round((num(v) + Number.EPSILON) * 100) / 100; }
  function sum(arr) { return r2(arr.reduce(function (a, b) { return a + num(b); }, 0)); }
  function median(arr) {
    var a = arr.slice().sort(function (x, y) { return x - y; });
    if (!a.length) return 0;
    return a.length % 2 ? a[(a.length - 1) / 2] : (a[a.length / 2 - 1] + a[a.length / 2]) / 2;
  }
  function fmt(v) {
    return num(v).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function pct(v) { return (num(v) * 100).toFixed(1) + '%'; }
  function monthLabel(m) { return m ? m.slice(0, 4) + '年' + Number(m.slice(5, 7)) + '月' : '全部月份'; }
  function dayLabel(d) { return d ? d.slice(5, 10) : ''; }
  function latestMonth(ds) { return ds.months.length ? ds.months[ds.months.length - 1] : ''; }

  /* 字级朴素贝叶斯推理（与 pipeline/classify.py 完全一致） */
  function tokenize(text) {
    var lower = String(text || '').toLowerCase();
    var chars = lower.match(/[\u4e00-\u9fff]|[a-z0-9]+/g) || [];
    var tokens = chars.slice();
    for (var i = 0; i < chars.length - 1; i++) tokens.push(chars[i] + chars[i + 1]);
    return tokens.length ? tokens : ['<empty>'];
  }
  function nbPredict(desc) {
    var m = DATA.model;
    if (!m || !m.loglik || !m.totals) return '';
    var tokens = tokenize(desc);
    var best = '', bestScore = -1e18;
    for (var i = 0; i < m.labels.length; i++) {
      var label = m.labels[i];
      var denom = m.totals[label] + m.alpha * m.vocab_size;
      var floor = Math.log(m.alpha / denom);
      var score = Math.log(m.priors[label] || 1e-9);
      for (var j = 0; j < tokens.length; j++) {
        var v = m.loglik[label][tokens[j]];
        score += (v == null ? floor : v);
      }
      if (score > bestScore) { bestScore = score; best = label; }
    }
    return best;
  }

  var toastTimer = null;
  function toast(msg) {
    var t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.hidden = false;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); t.hidden = true; }, 2400);
  }

  /* ============ 数据模型 ============ */
  var DS = CLEAN.datasets.map(function (d) {
    var cls = (DATA.classified && DATA.classified[d.id]) || {};
    var txns = d.txns.map(function (t) {
      var c = cls[t.txn_id] || {};
      return {
        id: t.txn_id, date: t.date, month: t.month, type: t.type, amount: num(t.amount),
        desc: t.desc, cat: c.pred || t.category_truth || '其他', baseCat: c.pred || t.category_truth || '其他',
        truth: t.category_truth || '',
        sub: t.subcategory || '', account: t.account || '', pay: t.pay || '',
        note: t.note || '', isOutlier: !!t.is_outlier,
        keyword: c.rule_hit || '', conf: typeof c.confidence === 'number' ? c.confidence : 0,
        engine: c.engine || 'rule', source: 'data'
      };
    });
    return {
      id: d.id, name: d.name, months: (d.months || []).slice(),
      budget: d.budget || {}, totals: d.totals || {}, recon: d.recon || [], txns: txns
    };
  });
  var IMPORT_ID = 'U1';
  var importDs = null;

  function ensureImportDs() {
    if (importDs) return importDs;
    importDs = {
      id: IMPORT_ID, name: '我的导入', months: [], budget: {},
      totals: {}, recon: [], txns: [], custom: true
    };
    DS.push(importDs);
    state.manual[IMPORT_ID] = [];
    state.overrides[IMPORT_ID] = {};
    state.budgetOverride[IMPORT_ID] = {};
    return importDs;
  }

  /* 导入数据集：月份、预算、对账、总额、异常全部按导入内容重新生成 */
  function rebuildImport(ds, skipped) {
    var mset = {};
    ds.txns.forEach(function (t) { if (t.month) mset[t.month] = 1; });
    ds.months = Object.keys(mset).sort();
    var exp = ds.txns.filter(function (t) { return t.type === '支出'; });
    var inc = ds.txns.filter(function (t) { return t.type === '收入'; });
    var expSum = sum(exp.map(function (t) { return t.amount; }));
    var incSum = sum(inc.map(function (t) { return t.amount; }));
    ds.totals = {
      raw_rows: ds.txns.length + num(skipped), dup_removed: num(skipped),
      clean_rows: ds.txns.length, expense: expSum, income: incSum,
      raw_expense: expSum, raw_income: incSum, dup_amount: 0
    };
    var n = Math.max(1, ds.months.length);
    var byCat = {};
    exp.forEach(function (t) { byCat[t.cat] = (byCat[t.cat] || 0) + t.amount; });
    ds.budget = {};
    Object.keys(byCat).forEach(function (c) {
      ds.budget[c] = {
        monthly: Math.max(50, Math.round(byCat[c] / n * 1.2 / 10) * 10),
        warn: 90, note: '按导入数据月均自动估算'
      };
    });
    ds.recon = ds.months.map(function (m) {
      var v = sum(exp.filter(function (t) { return t.month === m; }).map(function (t) { return t.amount; }));
      return { month: m, raw: v, clean: v, diff: 0 };
    });
    state.budgetOverride[IMPORT_ID] = {};
    markOutliers(ds);
  }

  var STORE_KEY = 't5_ledger_advanced_v1';
  function readStore() {
    try { return JSON.parse(window.localStorage.getItem(STORE_KEY) || '{}') || {}; } catch (e) { return {}; }
  }
  function writeStore() {
    try {
      window.localStorage.setItem(STORE_KEY, JSON.stringify({
        manual: state.manual, overrides: state.overrides, budget: state.budgetOverride,
        custom: importDs ? { name: importDs.name, txns: importDs.txns } : null
      }));
    } catch (e) { /* file:// 下可能被禁用，页面内仍然有效 */ }
  }

  var stored = readStore();
  DS.forEach(function (d) {
    var m = (stored.manual && stored.manual[d.id]) || [];
    state.manual[d.id] = m.map(function (t) { if (!t.baseCat) t.baseCat = t.cat; return t; });
    state.overrides[d.id] = (stored.overrides && stored.overrides[d.id]) || {};
    state.budgetOverride[d.id] = (stored.budget && stored.budget[d.id]) || {};
    state.manual[d.id].forEach(function (t) {
      var m = /^M-(\d+)$/.exec(t.id || '');
      if (m) state.uid = Math.max(state.uid, Number(m[1]));
    });
  });

  /* 恢复上次导入的数据集（若有） */
  if (stored.custom && stored.custom.txns && stored.custom.txns.length) {
    var cds = {
      id: IMPORT_ID, name: stored.custom.name || '我的导入', months: [], budget: {},
      totals: {}, recon: [], txns: stored.custom.txns, custom: true
    };
    DS.push(cds);
    importDs = cds;
    state.manual[IMPORT_ID] = [];
    state.overrides[IMPORT_ID] = {};
    state.budgetOverride[IMPORT_ID] = {};
    cds.txns.forEach(function (t) {
      var m = /^M-(\d+)$/.exec(t.id || '');
      if (m) state.uid = Math.max(state.uid, Number(m[1]));
    });
    rebuildImport(cds, 0);
    state.budgetOverride[IMPORT_ID] = (stored.budget && stored.budget[IMPORT_ID]) || {};
  }

  /* 双引擎对照：模型预测 + 人工校正应用 */
  DS.forEach(function (d) {
    var ov = state.overrides[d.id] || {};
    d.txns.forEach(function (t) {
      t.modelCat = nbPredict(t.desc);
      var hit = ov[t.id];
      if (hit && hit !== t.baseCat) { t.cat = hit; t.corrected = true; }
    });
    state.manual[d.id].forEach(function (t) {
      var hit = ov[t.id];
      if (hit) { t.cat = hit; t.corrected = hit !== t.baseCat; }
    });
  });
  state.month = latestMonth(DS[0]);

  function getDs(id) {
    for (var i = 0; i < DS.length; i++) if (DS[i].id === (id || state.ds)) return DS[i];
    return DS[0];
  }
  function allTxns(ds) { return ds.txns.concat(state.manual[ds.id] || []); }
  function monthTxns(ds) {
    var all = allTxns(ds);
    return state.month ? all.filter(function (t) { return t.month === state.month; }) : all;
  }
  function monthKeys(ds) {
    var set = {};
    allTxns(ds).forEach(function (t) { if (t.month) set[t.month] = 1; });
    return Object.keys(set).sort();
  }
  function expenseByCat(txns) {
    var map = {};
    txns.forEach(function (t) {
      if (t.type !== '支出') return;
      map[t.cat] = r2((map[t.cat] || 0) + t.amount);
    });
    return Object.keys(map).map(function (c) { return { cat: c, amount: map[c] }; })
      .sort(function (a, b) { return b.amount - a.amount; });
  }
  function totalsOf(txns) {
    var exp = sum(txns.filter(function (t) { return t.type === '支出'; }).map(function (t) { return t.amount; }));
    var inc = sum(txns.filter(function (t) { return t.type === '收入'; }).map(function (t) { return t.amount; }));
    return { expense: exp, income: inc, balance: r2(inc - exp) };
  }

  /* ============ 预算 ============ */
  function budgetRows(ds) {
    var mult = state.month ? 1 : Math.max(1, monthKeys(ds).length);
    var ov = state.budgetOverride[ds.id] || {};
    var rows = [];
    Object.keys(ds.budget).forEach(function (cat) {
      var b = ds.budget[cat] || {};
      var monthly = ov[cat] != null ? num(ov[cat]) : num(b.monthly);
      var budget = r2(monthly * mult);
      if (budget <= 0) return;
      var actual = sum(allTxns(ds).filter(function (t) {
        return t.cat === cat && t.type === '支出' && (!state.month || t.month === state.month);
      }).map(function (t) { return t.amount; }));
      var p = budget ? actual / budget * 100 : 0;
      var warn = num(b.warn) || 100;
      rows.push({
        cat: cat, budget: budget, actual: actual, pct: p,
        over: r2(Math.max(0, actual - budget)), warn: warn,
        monthly: monthly, changed: ov[cat] != null,
        status: p >= 100 ? '超支' : (p >= warn ? '接近预警' : '正常')
      });
    });
    return rows.sort(function (a, b) { return b.pct - a.pct; });
  }

  /* ============ 图表 ============ */
  function draw(id, option, onClick) {
    var el = document.getElementById(id);
    if (!el || !window.echarts || el.clientWidth === 0) return;
    var ph = el.querySelector('.empty');
    if (ph) el.removeChild(ph);
    var inst = state.charts[id];
    if (!inst) {
      inst = state.charts[id] = window.echarts.init(el, null, { renderer: 'canvas' });
    }
    inst.setOption(option, true);
    inst.off('click');
    if (onClick) inst.on('click', onClick);
    inst.resize();
  }

  /* 图表没有可画的数据时，清掉实例并给出占位说明 */
  function clearChart(id, msg) {
    var el = document.getElementById(id);
    if (!el) return;
    if (state.charts[id]) {
      state.charts[id].dispose();
      delete state.charts[id];
    }
    el.innerHTML = '<div class="empty">' + esc(msg) + '</div>';
  }
  function axisStyle() {
    return {
      axisLine: { lineStyle: { color: '#dfe8e3' } },
      axisTick: { show: false },
      axisLabel: { fontSize: 11, color: '#728a81' },
      splitLine: { lineStyle: { color: '#eff4f1' } }
    };
  }

  /* ============ 顶部 / 控制条 ============ */
  function renderDsSwitch() {
    var box = document.getElementById('dsSwitch');
    if (!box) return;
    box.innerHTML = DS.map(function (d) {
      return '<button data-ds="' + d.id + '" class="' + (d.id === state.ds ? 'active' : '') + '">' +
        d.id + ' · ' + esc(d.name) + '</button>';
    }).join('');
  }

  function renderMonthSelect() {
    var sel = document.getElementById('monthSelect');
    if (!sel) return;
    var months = monthKeys(getDs()).slice().reverse();
    var html = '<option value="">全部月份</option>';
    months.forEach(function (m) {
      html += '<option value="' + m + '">' + monthLabel(m) + '</option>';
    });
    sel.innerHTML = html;
    sel.value = state.month && months.indexOf(state.month) >= 0 ? state.month : '';
    if (state.month && months.indexOf(state.month) < 0) state.month = '';

    var fm = document.getElementById('filterMonth');
    if (fm) {
      var fh = '<option value="">全部月份</option>';
      months.forEach(function (m) { fh += '<option value="' + m + '">' + monthLabel(m) + '</option>'; });
      fm.innerHTML = fh;
      fm.value = state.filters.month;
    }
    var fc = document.getElementById('filterCategory');
    if (fc) {
      var cats = {};
      allTxns(getDs()).forEach(function (t) { cats[t.cat] = 1; });
      var ch = '<option value="">全部分类</option>';
      Object.keys(cats).forEach(function (c) { ch += '<option value="' + esc(c) + '">' + esc(c) + '</option>'; });
      fc.innerHTML = ch;
      fc.value = state.filters.cat;
    }
  }

  function renderHeadBadges() {
    var ds = getDs();
    var tx = monthTxns(ds);
    var t = totalsOf(tx);
    var ov = document.getElementById('overviewBadge');
    if (ov) ov.textContent = ds.name + ' · ' + monthLabel(state.month) + ' · ' + tx.length + ' 笔';

    var st = document.getElementById('structTotal');
    if (st) {
      var rows = expenseByCat(tx);
      st.textContent = '支出 ' + fmt(t.expense) + ' 元' + (rows.length ? ' · 最大 ' + rows[0].cat + ' ' + pct(rows[0].amount / (t.expense || 1)) : '');
    }
    var bb = document.getElementById('budgetBadge');
    if (bb) {
      var br = budgetRows(ds);
      var over = br.filter(function (r) { return r.pct >= 100; }).length;
      bb.textContent = br.length + ' 个预算分类 · 超支 ' + over + ' 项';
      bb.className = 'head-badge' + (over ? ' bad' : '');
    }
    var ab = document.getElementById('anomalyBadge');
    if (ab) {
      var an = tx.filter(function (x) { return x.type === '支出' && x.isOutlier; });
      ab.textContent = an.length + ' 笔 · 合计 ' + fmt(sum(an.map(function (x) { return x.amount; }))) + ' 元';
      ab.className = 'head-badge' + (an.length ? ' bad' : '');
    }
    var cb = document.getElementById('compareBadge');
    if (cb) {
      var ins = DATA.insight && DATA.insight.datasets && DATA.insight.datasets[ds.id];
      cb.textContent = ins ? ('口径 ' + monthLabel(ins.latest_month)) : '暂无对照数据';
    }
  }

  /* ============ 概览 ============ */
  function renderKpi() {
    var box = document.getElementById('kpiGrid');
    if (!box) return;
    var ds = getDs();
    var tx = monthTxns(ds);
    var t = totalsOf(tx);
    var br = budgetRows(ds);
    var budgeted = br.reduce(function (a, r) { return a + r.budget; }, 0);
    var actualBudgeted = br.reduce(function (a, r) { return a + Math.min(r.actual, r.budget); }, 0);
    var overCount = br.filter(function (r) { return r.pct >= 100; }).length;
    var an = tx.filter(function (x) { return x.type === '支出' && x.isOutlier; });

    function card(label, value, sub, tone, goto) {
      return '<button type="button" class="kpi ' + (tone || '') + '"' +
        (goto ? ' data-goto="' + goto + '"' : '') + '>' +
        '<span class="k-label">' + label + '</span>' +
        '<span class="k-value">' + value + '</span>' +
        '<span class="k-sub">' + sub + '</span></button>';
    }

    box.innerHTML = [
      card('支出', fmt(t.expense), monthLabel(state.month) + ' · ' + tx.filter(function (x) { return x.type === '支出'; }).length + ' 笔', '', 'detail'),
      card('收入', fmt(t.income), monthLabel(state.month) + ' · ' + tx.filter(function (x) { return x.type === '收入'; }).length + ' 笔', 'blue', 'detail'),
      card('结余', fmt(t.balance), t.balance < 0 ? '收不抵支' : '收入 − 支出', t.balance < 0 ? 'red' : ''),
      card('预算执行率', budgeted ? pct(actualBudgeted / budgeted) : '—', budgeted ? '预算合计 ' + fmt(budgeted) + ' 元' : '未配置预算', 'amber', 'budget'),
      card('超支分类', overCount + ' 项', br.length ? '共 ' + br.length + ' 个预算分类' : '未配置预算', overCount ? 'red' : '', 'budget'),
      card('异常支出', an.length + ' 笔', '合计 ' + fmt(sum(an.map(function (x) { return x.amount; }))) + ' 元', an.length ? 'amber' : '', 'anomaly')
    ].join('');
  }

  function renderPieMini() {
    var ds = getDs();
    var rows = expenseByCat(monthTxns(ds));
    if (!rows.length) { return; }
    draw('chartPieMini', {
      color: rows.map(function (r) { return COLORS[r.cat] || '#8b98a0'; }),
      tooltip: { trigger: 'item', confine: true, formatter: function (p) { return p.name + '<br/><b>' + fmt(p.value) + '</b> 元 · ' + p.percent + '%'; } },
      series: [{
        type: 'pie', radius: ['45%', '72%'], center: ['50%', '52%'],
        itemStyle: { borderColor: '#fff', borderWidth: 2, borderRadius: 5 },
        label: { show: true, formatter: '{b}\n{d}%', fontSize: 10, color: '#41514a', lineHeight: 13 },
        labelLine: { length: 8, length2: 6, lineStyle: { color: '#c9d6d0' } },
        data: rows.map(function (r) { return { name: r.cat, value: r.amount }; })
      }]
    }, function (p) { drill(p.name); });
  }

  function renderOverviewTrend() {
    var ds = getDs();
    var months = monthKeys(ds);
    if (state.month) months = months.filter(function (m) { return m <= state.month; });
    months = months.slice(-3);
    if (!months.length) return;
    var exp = [], inc = [];
    months.forEach(function (m) {
      var tx = allTxns(ds).filter(function (t) { return t.month === m; });
      var t = totalsOf(tx);
      exp.push(t.expense); inc.push(t.income);
    });
    var ax = axisStyle();
    draw('chartOverviewTrend', {
      color: ['#0e6b4f', '#e0a30a'],
      tooltip: { trigger: 'axis', confine: true, valueFormatter: function (v) { return fmt(v) + ' 元'; } },
      legend: { data: ['支出', '收入'], bottom: 0, icon: 'roundRect', itemWidth: 9, itemHeight: 9, textStyle: { fontSize: 11, color: '#728a81' } },
      grid: { left: 4, right: 12, top: 18, bottom: 34, containLabel: true },
      xAxis: { type: 'category', data: months.map(monthLabel), axisLine: ax.axisLine, axisTick: ax.axisTick, axisLabel: ax.axisLabel },
      yAxis: { type: 'value', splitLine: ax.splitLine, axisLabel: { fontSize: 11, color: '#728a81', formatter: function (v) { return v >= 1000 ? (v / 1000) + 'k' : v; } } },
      series: [
        { name: '支出', type: 'bar', data: exp, barWidth: '34%', itemStyle: { borderRadius: [5, 5, 0, 0] } },
        { name: '收入', type: 'line', data: inc, smooth: true, symbolSize: 6, lineStyle: { width: 2.4 } }
      ]
    });
  }

  function renderSummary() {
    var box = document.getElementById('summaryList');
    if (!box) return;
    var ds = getDs();
    var ins = DATA.insight && DATA.insight.datasets && DATA.insight.datasets[ds.id];
    if (!ins) { box.innerHTML = '<div class="empty">暂无自动小结</div>'; return; }
    var lines = (ins.monthly_summaries && state.month && ins.monthly_summaries[state.month]) || ins.summary || [];
    var manualCount = (state.manual[ds.id] || []).length;
    box.innerHTML = lines.map(function (s, i) {
      var dis = s.indexOf('仅') >= 0 && s.indexOf('描述性统计') >= 0;
      return '<div class="s-item' + (dis ? ' disclaimer' : '') + '"><span class="s-idx">' + (dis ? '!' : (i + 1)) + '</span><span>' + esc(s) + '</span></div>';
    }).join('') + (manualCount ? '<div class="s-item disclaimer"><span class="s-idx">+</span><span>本次页面新增 ' + manualCount + ' 笔，未计入以上文字小结（小结来自离线管线）。</span></div>' : '');
  }

  /* ============ 结构 ============ */
  function renderStructure() {
    var ds = getDs();
    var tx = monthTxns(ds);
    var rows = expenseByCat(tx);
    var total = sum(rows.map(function (r) { return r.amount; }));
    if (rows.length) {
      draw('chartPie', {
        color: rows.map(function (r) { return COLORS[r.cat] || '#8b98a0'; }),
        tooltip: { trigger: 'item', confine: true, formatter: function (p) { return p.name + '<br/><b>' + fmt(p.value) + '</b> 元 · ' + p.percent + '%'; } },
        legend: { type: 'scroll', bottom: 0, icon: 'circle', itemWidth: 8, itemHeight: 8, textStyle: { fontSize: 11, color: '#728a81' } },
        series: [{
          type: 'pie', radius: ['40%', '64%'], center: ['50%', '46%'],
          itemStyle: { borderColor: '#fff', borderWidth: 2, borderRadius: 6 },
          label: { show: true, formatter: '{b} {d}%', fontSize: 11, color: '#41514a' },
          labelLine: { length: 10, length2: 8, lineStyle: { color: '#c9d6d0' } },
          data: rows.map(function (r) { return { name: r.cat, value: r.amount }; })
        }]
      }, function (p) { drill(p.name); });
    }

    var prevMonth = '';
    if (state.month) {
      var ms = monthKeys(ds);
      var i = ms.indexOf(state.month);
      if (i > 0) prevMonth = ms[i - 1];
    }
    var prevMap = {};
    if (prevMonth) {
      expenseByCat(allTxns(ds).filter(function (t) { return t.month === prevMonth; }))
        .forEach(function (r) { prevMap[r.cat] = r.amount; });
    }

    var box = document.getElementById('rankList');
    if (!box) return;
    if (!rows.length) { box.innerHTML = '<div class="empty">本月暂无支出记录</div>'; return; }
    box.innerHTML = rows.map(function (r) {
      var share = total ? r.amount / total : 0;
      var mom = '';
      if (prevMonth) {
        if (prevMap[r.cat] == null) mom = '<span class="up">上月无此项</span>';
        else {
          var d = r.amount - prevMap[r.cat];
          mom = '<span class="' + (d > 0 ? 'up' : 'down') + '">' + (d > 0 ? '+' : '') + fmt(d) + ' 元</span>';
        }
      }
      return '<div class="rank-row" data-cat="' + esc(r.cat) + '">' +
        '<span class="rank-name"><i class="rank-dot" style="background:' + (COLORS[r.cat] || '#8b98a0') + '"></i>' + esc(r.cat) + '</span>' +
        '<span class="rank-bar"><i style="width:' + Math.max(2, share * 100).toFixed(1) + '%;background:' + (COLORS[r.cat] || '#8b98a0') + '"></i></span>' +
        '<span class="rank-num"><b>' + fmt(r.amount) + '</b><span>' + pct(share) + '</span>' + mom + '</span></div>';
    }).join('');
  }

  /* ============ 固定 / 弹性支出 ============ */
  var FIXED_CATS = ['居住', '通讯', '交通'];
  function fixedSplit(tx) {
    var exp = tx.filter(function (t) { return t.type === '支出'; });
    var fixed = sum(exp.filter(function (t) { return FIXED_CATS.indexOf(t.cat) >= 0; }).map(function (t) { return t.amount; }));
    var total = sum(exp.map(function (t) { return t.amount; }));
    var flex = r2(total - fixed);
    var income = sum(tx.filter(function (t) { return t.type === '收入'; }).map(function (t) { return t.amount; }));
    return {
      fixed: fixed, flex: flex, total: total,
      fixedShare: total ? fixed / total : 0,
      flexShare: total ? flex / total : 0,
      cover: income ? fixed / income : 0
    };
  }

  function renderFixed() {
    var box = document.getElementById('fixedBody');
    if (!box) return;
    var ds = getDs();
    var tx = monthTxns(ds);
    var s = fixedSplit(tx);
    if (!s.total) {
      box.innerHTML = '<div class="empty">当前范围没有支出记录</div>';
      return;
    }
    var fixedW = (s.fixedShare * 100).toFixed(1);
    var flexW = (s.flexShare * 100).toFixed(1);
    var byCat = expenseByCat(tx);
    var fixedRows = byCat.filter(function (r) { return FIXED_CATS.indexOf(r.cat) >= 0; });
    box.innerHTML =
      '<div class="split-bar" role="img" aria-label="固定支出占比 ' + fixedW + '%">' +
      '<i class="fixed" style="width:' + fixedW + '%"></i><i class="flex" style="width:' + flexW + '%"></i></div>' +
      '<div class="split-legend">' +
      '<div><span class="sw fixed"></span><span class="sl">固定支出</span><b>' + fmt(s.fixed) + '</b> 元 · ' + fixedW + '%</div>' +
      '<div><span class="sw flex"></span><span class="sl">弹性支出</span><b>' + fmt(s.flex) + '</b> 元 · ' + flexW + '%</div>' +
      '</div>' +
      '<p class="footnote">固定支出覆盖收入 ' + (s.cover ? pct(s.cover) : '—') +
      (fixedRows.length ? '　其中 ' + fixedRows.map(function (r) { return r.cat + ' ' + fmt(r.amount) + ' 元'; }).join('、') : '') +
      '。固定＝居住 / 通讯 / 交通；其余支出（含餐饮、购物、娱乐等）计入弹性，是本月可压缩的部分。</p>';
  }

  /* ============ 趋势 ============ */
  function renderTrend() {
    var ds = getDs();
    var months = monthKeys(ds);
    if (!months.length) return;
    var all = allTxns(ds);
    var catTotals = {};
    all.forEach(function (t) {
      if (t.type !== '支出') return;
      catTotals[t.cat] = (catTotals[t.cat] || 0) + t.amount;
    });
    var cats = Object.keys(catTotals).sort(function (a, b) { return catTotals[b] - catTotals[a]; });

    var series = cats.map(function (c) {
      return {
        name: c, type: 'bar', stack: 'total', emphasis: { focus: 'series' },
        itemStyle: { color: COLORS[c] || '#8b98a0' },
        data: months.map(function (m) {
          return sum(all.filter(function (t) { return t.month === m && t.type === '支出' && t.cat === c; })
            .map(function (t) { return t.amount; }));
        })
      };
    });
    var expLine = {
      name: '支出合计', type: 'line', smooth: true, symbolSize: 6, z: 10,
      lineStyle: { width: 2.4, color: '#0b3d2e' }, itemStyle: { color: '#0b3d2e' },
      data: months.map(function (m) {
        return totalsOf(all.filter(function (t) { return t.month === m; })).expense;
      })
    };
    /* 顶部月份选择器不影响整段趋势，用一条竖虚线标出当前月份，避免误以为“切换无变化” */
    if (state.month && months.indexOf(state.month) >= 0) {
      expLine.markLine = {
        silent: true, symbol: 'none',
        lineStyle: { color: '#0e6b4f', type: 'dashed', width: 1.4 },
        label: { formatter: '当前月份', fontSize: 10, color: '#0e6b4f', position: 'insideEndTop' },
        data: [{ xAxis: monthLabel(state.month) }]
      };
    }
    if (state.trendMode === 'all') {
      series.push(expLine);
      series.push({
        name: '收入合计', type: 'line', smooth: true, symbolSize: 6, z: 10,
        lineStyle: { width: 2.4, color: '#e0a30a', type: 'dashed' }, itemStyle: { color: '#e0a30a' },
        data: months.map(function (m) {
          return totalsOf(all.filter(function (t) { return t.month === m; })).income;
        })
      });
    } else {
      series.push(expLine);
    }
    var ax = axisStyle();
    draw('chartTrend', {
      tooltip: { trigger: 'axis', confine: true, axisPointer: { type: 'shadow' } },
      legend: { type: 'scroll', bottom: 0, icon: 'roundRect', itemWidth: 9, itemHeight: 9, textStyle: { fontSize: 11, color: '#728a81' } },
      grid: { left: 6, right: 16, top: 20, bottom: 52, containLabel: true },
      xAxis: { type: 'category', data: months.map(monthLabel), axisLine: ax.axisLine, axisTick: ax.axisTick, axisLabel: ax.axisLabel },
      yAxis: { type: 'value', splitLine: ax.splitLine, axisLabel: { fontSize: 11, color: '#728a81', formatter: function (v) { return v >= 1000 ? (v / 1000) + 'k' : v; } } },
      series: series
    });
  }

  function renderRecon() {
    var tbl = document.getElementById('reconTable');
    if (!tbl) return;
    var ds = getDs();
    var recon = ds.recon || [];
    if (!recon.length) { tbl.innerHTML = '<tbody><tr><td class="dim">暂无对账数据</td></tr></tbody>'; return; }
    var rawSum = sum(recon.map(function (r) { return r.raw; }));
    var cleanSum = sum(recon.map(function (r) { return r.clean; }));
    var rows = recon.map(function (r) {
      return '<tr><td>' + esc(r.month) + '</td><td class="num">' + fmt(r.raw) + '</td><td class="num">' + fmt(r.clean) +
        '</td><td class="num">' + fmt(r.diff) + '</td><td>' + (Math.abs(r.diff) < 0.005 ? '<span class="dot-ok">差额 0.00 ✓</span>' : '<span class="pill expense">差额 ' + fmt(r.diff) + '</span>') + '</td></tr>';
    }).join('');
    tbl.innerHTML =
      '<thead><tr><th>月份</th><th class="num">原始导入合计</th><th class="num">清洗后合计</th><th class="num">差额</th><th>结论</th></tr></thead>' +
      '<tbody>' + rows +
      '<tr class="total"><td>合计</td><td class="num">' + fmt(rawSum) + '</td><td class="num">' + fmt(cleanSum) +
      '</td><td class="num">' + fmt(r2(rawSum - cleanSum)) + '</td><td>逐月逐类核对通过</td></tr></tbody>';
  }

  /* ============ 结余率 / 储蓄率走势 ============ */
  function renderSavings() {
    var ds = getDs();
    var months = monthKeys(ds);
    if (!months.length) { clearChart('chartSavings', '暂无月份数据'); return; }
    var all = allTxns(ds);
    var bal = [], rate = [];
    months.forEach(function (m) {
      var t = totalsOf(all.filter(function (x) { return x.month === m; }));
      bal.push(t.balance);
      rate.push(t.income > 0 ? Math.round(t.balance / t.income * 1000) / 10 : null);
    });
    var ax = axisStyle();
    draw('chartSavings', {
      tooltip: {
        trigger: 'axis', confine: true,
        formatter: function (ps) {
          var out = ps[0].axisValue;
          ps.forEach(function (p) {
            out += '<br/>' + p.marker + p.seriesName + '：<b>' +
              (p.seriesName === '结余率' ? (p.value == null ? '—' : p.value + '%') : fmt(p.value) + ' 元') + '</b>';
          });
          return out;
        }
      },
      legend: { data: ['结余金额', '结余率'], bottom: 0, icon: 'roundRect', itemWidth: 9, itemHeight: 9, textStyle: { fontSize: 11, color: '#728a81' } },
      grid: { left: 6, right: 16, top: 22, bottom: 34, containLabel: true },
      xAxis: { type: 'category', data: months.map(monthLabel), axisLine: ax.axisLine, axisTick: ax.axisTick, axisLabel: ax.axisLabel },
      yAxis: [
        { type: 'value', name: '元', nameTextStyle: { fontSize: 10, color: '#728a81' }, splitLine: ax.splitLine, axisLabel: { fontSize: 11, color: '#728a81', formatter: function (v) { return Math.abs(v) >= 1000 ? (v / 1000) + 'k' : v; } } },
        { type: 'value', name: '%', nameTextStyle: { fontSize: 10, color: '#728a81' }, splitLine: { show: false }, axisLabel: { fontSize: 11, color: '#728a81', formatter: '{value}%' } }
      ],
      series: [
        {
          name: '结余金额', type: 'bar', barMaxWidth: 26,
          data: bal.map(function (v) {
            return { value: v, itemStyle: { color: v < 0 ? '#b3352c' : '#0e6b4f', borderRadius: [4, 4, 0, 0] } };
          })
        },
        {
          name: '结余率', type: 'line', yAxisIndex: 1, data: rate, smooth: true, symbolSize: 6,
          connectNulls: false, lineStyle: { width: 2.4, color: '#e0a30a' }, itemStyle: { color: '#e0a30a' }
        }
      ]
    });
  }

  /* ============ 环比变化瀑布 ============ */
  function renderWaterfall() {
    var ds = getDs();
    var ms = monthKeys(ds);
    var idx = state.month ? ms.indexOf(state.month) : -1;
    if (!state.month || idx <= 0) { clearChart('chartWaterfall', '请选择具体月份，且该月存在上月数据'); return; }
    var curM = state.month, prevM = ms[idx - 1];
    var all = allTxns(ds);
    var prevMap = {}, curMap = {};
    expenseByCat(all.filter(function (t) { return t.month === prevM; })).forEach(function (r) { prevMap[r.cat] = r.amount; });
    expenseByCat(all.filter(function (t) { return t.month === curM; })).forEach(function (r) { curMap[r.cat] = r.amount; });
    var prevTotal = sum(Object.keys(prevMap).map(function (c) { return prevMap[c]; }));
    var curTotal = sum(Object.keys(curMap).map(function (c) { return curMap[c]; }));
    if (!prevTotal && !curTotal) { clearChart('chartWaterfall', '这两个月都没有支出记录'); return; }

    var names = {};
    Object.keys(prevMap).concat(Object.keys(curMap)).forEach(function (c) { names[c] = 1; });
    var list = Object.keys(names).map(function (c) {
      var p = prevMap[c] || 0, v = curMap[c] || 0;
      return { cat: c, prev: p, cur: v, delta: r2(v - p) };
    }).filter(function (r) { return Math.abs(r.delta) > 0.004; })
      .sort(function (a, b) { return Math.abs(b.delta) - Math.abs(a.delta); });

    var labels = ['上月合计'], bases = [0], vals = [prevTotal], cols = ['#8b98a0'];
    list.forEach(function (r) {
      labels.push(r.cat);
      if (r.delta >= 0) { bases.push(r.prev); vals.push(r.delta); cols.push('#b3352c'); }
      else { bases.push(r.cur); vals.push(-r.delta); cols.push('#0e6b4f'); }
    });
    labels.push('本月合计');
    bases.push(0); vals.push(curTotal); cols.push('#0b3d2e');

    var ax = axisStyle();
    draw('chartWaterfall', {
      tooltip: {
        trigger: 'item', confine: true,
        formatter: function (p) {
          var i = p.dataIndex;
          if (i === 0) return '上月合计<br/><b>' + fmt(prevTotal) + '</b> 元（' + monthLabel(prevM) + '）';
          if (i === labels.length - 1) {
            return '本月合计<br/><b>' + fmt(curTotal) + '</b> 元（' + monthLabel(curM) + '）<br/>环比 ' +
              (curTotal >= prevTotal ? '+' : '') + fmt(r2(curTotal - prevTotal)) + ' 元';
          }
          var r = list[i - 1];
          return esc(r.cat) + '<br/>上月 ' + fmt(r.prev) + ' → 本月 ' + fmt(r.cur) +
            '<br/><b>' + (r.delta > 0 ? '+' : '') + fmt(r.delta) + '</b> 元';
        }
      },
      grid: { left: 6, right: 14, top: 22, bottom: 50, containLabel: true },
      xAxis: { type: 'category', data: labels, axisLine: ax.axisLine, axisTick: ax.axisTick, axisLabel: { fontSize: 10.5, color: '#728a81', interval: 0, rotate: labels.length > 6 ? 26 : 0 } },
      yAxis: { type: 'value', splitLine: ax.splitLine, axisLabel: { fontSize: 11, color: '#728a81', formatter: function (v) { return Math.abs(v) >= 1000 ? (v / 1000) + 'k' : v; } } },
      series: [
        { name: '占位', type: 'bar', stack: 'w', silent: true, itemStyle: { color: 'transparent' }, data: bases },
        {
          name: '变化', type: 'bar', stack: 'w', barMaxWidth: 30,
          label: {
            show: true, position: 'top', fontSize: 10, color: '#41514a',
            formatter: function (p) {
              var i = p.dataIndex;
              if (i === 0 || i === labels.length - 1) return '';
              var r = list[i - 1];
              return (r.delta > 0 ? '+' : '') + Math.round(r.delta);
            }
          },
          data: vals.map(function (v, i) {
            return { value: v, itemStyle: { color: cols[i], borderRadius: [3, 3, 0, 0] } };
          })
        }
      ]
    });
  }

  /* ============ 预算 ============ */
  function renderBudget() {
    var ds = getDs();
    var rows = budgetRows(ds);
    var kbox = document.getElementById('budgetKpi');
    if (kbox) {
      var budgetTotal = sum(rows.map(function (r) { return r.budget; }));
      var actualTotal = sum(rows.map(function (r) { return r.actual; }));
      var over = rows.filter(function (r) { return r.pct >= 100; });
      var overAmt = sum(over.map(function (r) { return r.over; }));
      kbox.innerHTML = [
        '<div class="kpi"><span class="k-label">预算合计</span><span class="k-value small">' + fmt(budgetTotal) + '</span><span class="k-sub">' + monthLabel(state.month) + (state.month ? '' : ' × ' + monthKeys(ds).length + ' 个月') + '</span></div>',
        '<div class="kpi blue"><span class="k-label">预算内实际支出</span><span class="k-value small">' + fmt(actualTotal) + '</span><span class="k-sub">' + rows.length + ' 个分类合计</span></div>',
        '<div class="kpi amber"><span class="k-label">预算执行率</span><span class="k-value small">' + (budgetTotal ? pct(actualTotal / budgetTotal) : '—') + '</span><span class="k-sub">实际 ÷ 预算</span></div>',
        '<div class="kpi ' + (over.length ? 'red' : '') + '"><span class="k-label">超支分类</span><span class="k-value small">' + over.length + ' 项</span><span class="k-sub">超出 ' + fmt(overAmt) + ' 元</span></div>'
      ].join('');
    }

    var box = document.getElementById('budgetList');
    if (!box) return;
    if (!rows.length) { box.innerHTML = '<div class="empty">该数据集未配置预算</div>'; return; }
    box.innerHTML = rows.map(function (r) {
      var cls = r.pct >= 100 ? 'red' : (r.pct >= r.warn ? 'amber' : '');
      var stCls = r.pct >= 100 ? 'bad' : (r.pct >= r.warn ? 'warn' : 'ok');
      var fill = Math.min(100, r.pct);
      return '<div class="budget-row">' +
        '<span class="budget-name"><i class="rank-dot" style="background:' + (COLORS[r.cat] || '#8b98a0') + '"></i>' + esc(r.cat) + '</span>' +
        '<span class="budget-track ' + cls + '"><i style="width:' + fill.toFixed(1) + '%"></i>' +
        (r.warn < 100 ? '<span class="budget-warnmark" style="left:' + r.warn + '%" title="预警线 ' + r.warn + '%"></span>' : '') + '</span>' +
        '<span class="budget-num"><b>' + fmt(r.actual) + '</b> / ' + fmt(r.budget) + ' 元 · ' + r.pct.toFixed(1) + '%' +
        '<span class="budget-status ' + stCls + '">' + r.status + (r.over > 0 ? ' +' + fmt(r.over) : '') + '</span></span>' +
        '<input class="budget-input' + (r.changed ? ' changed' : '') + '" type="number" min="0" step="50" ' +
        'value="' + r.monthly + '" data-bcat="' + esc(r.cat) + '" title="月预算，可直接修改（留空恢复默认）"></div>';
    }).join('');
  }

  /* ============ 异常 ============ */
  function renderAnomaly() {
    var box = document.getElementById('anomalyList');
    if (!box) return;
    var ds = getDs();
    var all = allTxns(ds);
    var byCat = {};
    all.forEach(function (t) {
      if (t.type !== '支出') return;
      if (!byCat[t.cat]) byCat[t.cat] = [];
      byCat[t.cat].push(t.amount);
    });
    var medOf = function (cat) { return median(byCat[cat] || []); };
    var monthExpTotal = sum(monthTxns(ds).filter(function (x) { return x.type === '支出'; })
      .map(function (x) { return x.amount; }));
    var list = monthTxns(ds).filter(function (t) { return t.type === '支出' && t.isOutlier; })
      .sort(function (a, b) { return b.amount - a.amount; });
    if (!list.length) {
      box.innerHTML = '<div class="empty">当前范围没有触发异常规则的支出</div>';
      return;
    }
    box.innerHTML = list.map(function (t) {
      var med = medOf(t.cat);
      var ratio = med ? t.amount / med : 0;
      var after = r2(monthExpTotal - t.amount);
      return '<div class="anomaly-card">' +
        '<div class="a-top"><span class="a-amt">' + fmt(t.amount) + '</span>' +
        '<span class="a-ratio">同类中位数 ' + (ratio ? ratio.toFixed(1) + ' 倍' : '—') + '</span></div>' +
        '<div class="a-desc">' + esc(t.desc) + '</div>' +
        '<div class="a-meta"><span>' + esc(t.cat) + ' · ' + esc(dayLabel(t.date)) + '</span>' +
        '<span>' + esc(t.account || '—') + '</span>' +
        '<span>同类中位数 ' + fmt(med) + ' 元</span>' +
        '<span>剔除本笔后本月支出 ' + fmt(after) + ' 元</span></div></div>';
    }).join('');
  }

  /* ============ 账户维度 ============ */
  function renderAccount() {
    var card = document.getElementById('accountCard');
    if (!card) return;
    var ds = getDs();
    var map = {};
    monthTxns(ds).forEach(function (t) {
      if (t.type !== '支出') return;
      var a = t.account || '未指定';
      map[a] = r2((map[a] || 0) + t.amount);
    });
    var rows = Object.keys(map).map(function (a) { return { name: a, value: map[a] }; })
      .sort(function (x, y) { return y.value - x.value; });
    card.hidden = rows.length < 2;
    if (rows.length < 2) return;
    var total = sum(rows.map(function (r) { return r.value; }));
    var names = rows.map(function (r) { return r.name; }).reverse();
    var vals = rows.map(function (r) { return r.value; }).reverse();
    draw('chartAccount', {
      color: ['#0e6b4f', '#2f7bd6', '#e0a30a', '#d4599a', '#6c5ce7', '#16a085'],
      tooltip: {
        trigger: 'axis', confine: true, axisPointer: { type: 'shadow' },
        formatter: function (ps) {
          var p = ps[0];
          var v = num(p.value);
          return p.name + '<br/><b>' + fmt(v) + '</b> 元 · ' + ((v / total) * 100).toFixed(1) + '%';
        }
      },
      grid: { left: 6, right: 26, top: 10, bottom: 6, containLabel: true },
      xAxis: { type: 'value', splitLine: axisStyle().splitLine, axisLabel: { fontSize: 11, color: '#728a81' } },
      yAxis: { type: 'category', data: names, axisLine: { show: false }, axisTick: { show: false }, axisLabel: { fontSize: 11.5, color: '#41514a' } },
      series: [{ type: 'bar', colorBy: 'data', data: vals, barMaxWidth: 22, itemStyle: { borderRadius: [0, 5, 5, 0] } }]
    }, function (p) {
      state.filters = { q: p.name, type: '支出', month: state.month || '', cat: '' };
      syncFilterInputs();
      showTab('detail');
      toast('已筛选账户：' + p.name);
    });
  }

  /* ============ 复核 ============ */
  function reviewStats(ds) {
    var ov = state.overrides[ds.id] || {};
    var disagree = [], resolved = 0, adoptModel = 0, adoptRule = 0, custom = 0;
    ds.txns.forEach(function (t) {
      if (!t.modelCat || t.modelCat === t.baseCat) return;
      disagree.push(t);
      if (t.id in ov) {
        resolved += 1;
        if (ov[t.id] === t.modelCat) adoptModel += 1;
        else if (ov[t.id] === t.baseCat) adoptRule += 1;
        else custom += 1;
      }
    });
    return {
      total: ds.txns.length, disagree: disagree.length,
      queue: disagree.filter(function (t) { return !(t.id in ov); }),
      resolved: resolved, adoptModel: adoptModel, adoptRule: adoptRule, custom: custom
    };
  }

  function findTxn(id) {
    var txns = getDs().txns;
    for (var i = 0; i < txns.length; i++) if (txns[i].id === id) return txns[i];
    return null;
  }

  function applyReview(id, cat) {
    var ds = getDs();
    var t = findTxn(id);
    if (!t || !cat) return;
    state.overrides[ds.id][id] = cat;
    t.cat = cat;
    t.corrected = cat !== t.baseCat;
    writeStore();
    renderAll();
    toast('已确认「' + t.desc + '」为 ' + cat + (cat === t.baseCat ? '（维持规则）' : '（已改分类）'));
  }

  function renderReview() {
    var ds = getDs();
    var st = reviewStats(ds);

    var badge = document.getElementById('reviewBadge');
    if (badge) {
      badge.textContent = st.queue.length + ' 笔待复核 · 已确认 ' + st.resolved;
      badge.className = 'head-badge' + (st.queue.length ? ' warn' : '');
    }

    var kbox = document.getElementById('reviewKpi');
    if (kbox) {
      var agree = st.total - st.disagree;
      kbox.innerHTML = [
        '<div class="kpi"><span class="k-label">规则 / 模型一致</span><span class="k-value small">' + (st.total ? pct(agree / st.total) : '—') + '</span><span class="k-sub">' + agree + ' / ' + st.total + ' 笔</span></div>',
        '<div class="kpi amber"><span class="k-label">双引擎分歧</span><span class="k-value small">' + st.disagree + ' 笔</span><span class="k-sub">模型与规则结论不同</span></div>',
        '<div class="kpi"><span class="k-label">已人工确认</span><span class="k-value small">' + st.resolved + ' 笔</span><span class="k-sub">采用模型 ' + st.adoptModel + ' · 采用规则 ' + st.adoptRule + ' · 其他 ' + st.custom + '</span></div>',
        '<div class="kpi blue"><span class="k-label">待复核</span><span class="k-value small">' + st.queue.length + ' 笔</span><span class="k-sub">确认后全站实时重算</span></div>'
      ].join('');
    }

    var box = document.getElementById('reviewList');
    if (box) {
      if (!st.queue.length) {
        box.innerHTML = '<div class="empty">当前数据集没有待复核的分歧交易' +
          (st.disagree ? '（' + st.disagree + ' 笔已全部确认）' : '') + '。</div>';
      } else {
        var catOpts = ['餐饮', '居住', '交通', '通讯', '购物', '衣着', '娱乐', '学习', '医疗', '其他',
          '工资收入', '兼职收入', '理财收益', '红包转账'];
        box.innerHTML = st.queue.map(function (t) {
          var opts = '<option value="">改其他分类…</option>' + catOpts.map(function (c) {
            return '<option value="' + c + '">' + c + '</option>';
          }).join('');
          return '<div class="review-item" data-review="' + esc(t.id) + '">' +
            '<div class="r-main"><div class="r-desc">' + esc(t.desc) + '</div>' +
            '<div class="r-meta"><span>' + esc(t.date) + '</span><span>' + esc(t.account || '—') + '</span>' +
            '<span>' + fmt(t.amount) + ' 元（' + esc(t.type) + '）</span></div>' +
            '<div class="r-engines"><span class="engine rule">规则 <b>' + esc(t.baseCat) + '</b></span>' +
            '<span class="arrow">vs</span>' +
            '<span class="engine model">模型 <b>' + esc(t.modelCat) + '</b></span></div></div>' +
            '<div class="r-actions">' +
            '<button class="ghost" type="button" data-act="rule">采用规则</button>' +
            '<button class="ghost" type="button" data-act="model">采用模型</button>' +
            '<select data-review-select>' + opts + '</select></div></div>';
        }).join('');
      }
    }

    var logTbl = document.getElementById('reviewLog');
    if (logTbl) {
      var ov = state.overrides[ds.id] || {};
      var entries = ds.txns.filter(function (t) { return t.id in ov; });
      if (!entries.length) {
        logTbl.innerHTML = '<tbody><tr><td class="dim" style="padding:22px;text-align:center">还没有人工确认记录</td></tr></tbody>';
      } else {
        logTbl.innerHTML = '<thead><tr><th>日期</th><th class="wrap">描述</th><th>规则</th><th>模型</th><th>人工结论</th><th>影响</th></tr></thead><tbody>' +
          entries.map(function (t) {
            var finalCat = ov[t.id];
            return '<tr><td>' + esc(t.date) + '</td><td class="wrap">' + esc(t.desc) + '</td>' +
              '<td>' + esc(t.baseCat) + '</td><td>' + esc(t.modelCat || '—') + '</td>' +
              '<td><span class="pill">' + esc(finalCat) + '</span></td>' +
              '<td>' + (finalCat === t.baseCat ? '<span class="dim">维持规则</span>' : '<span class="pill amber">已改分类</span>') + '</td></tr>';
          }).join('') + '</tbody>';
      }
    }
  }

  /* ============ 离线评测 ============ */
  function renderEval() {
    var kbox = document.getElementById('evalKpi');
    var note = document.getElementById('evalNote');
    if (!kbox) return;
    var e = DATA.eval;
    if (!e) {
      kbox.innerHTML = '<div class="empty">暂无离线评测结果</div>';
      if (note) note.textContent = '请先运行 python pipeline/classify.py 重新生成 out/eval.json。';
      return;
    }
    var folds = e.fold_accuracies || [];
    var spread = folds.length ? (Math.max.apply(null, folds) - Math.min.apply(null, folds)) * 100 : 0;
    var std = num(e.model_accuracy_std) * 100;
    kbox.innerHTML = [
      '<div class="kpi"><span class="k-label">规则引擎准确率</span><span class="k-value small">' + pct(e.rule_accuracy) + '</span><span class="k-sub">' + (e.n || 0) + ' 笔全量覆盖</span></div>',
      '<div class="kpi blue"><span class="k-label">朴素贝叶斯（' + (e.cv_k || 5) + ' 折均值）</span><span class="k-value small">' + pct(e.model_accuracy) + '</span><span class="k-sub">± ' + std.toFixed(2) + ' 个百分点</span></div>',
      '<div class="kpi"><span class="k-label">折间稳定性</span><span class="k-value small">' + spread.toFixed(1) + 'pp</span><span class="k-sub">各折极差，越小越稳定</span></div>',
      '<div class="kpi amber"><span class="k-label">每折测试样本</span><span class="k-value small">' + (e.test_size || 0) + '</span><span class="k-sub">训练 ' + (e.train_size || 0) + ' 笔 · 共 ' + (e.n || 0) + ' 笔</span></div>'
    ].join('');
    if (note) {
      note.innerHTML = '各折准确率：' + (folds.length ? folds.map(function (v, i) {
        return '第' + (i + 1) + '折 ' + pct(v);
      }).join(' · ') : '—') + '<br>特征：' + esc(e.features || '—') + '　' + esc(e.note || '');
    }
  }

  /* ============ 一键自检 ============ */
  function runSelfCheck() {
    var box = document.getElementById('selfCheckList');
    var badge = document.getElementById('selfCheckBadge');
    if (!box) return;
    var ds = getDs();
    var all = allTxns(ds);
    var cur = monthTxns(ds);
    var checks = [];
    function add(name, status, detail) { checks.push({ name: name, status: status, detail: detail }); }

    /* 1 数据格式：日期合法、金额为正、描述非空 */
    var bad = [], scanned = 0;
    DS.forEach(function (d) {
      allTxns(d).forEach(function (t) {
        scanned += 1;
        if (!/^20\d{2}-\d{2}-\d{2}$/.test(t.date) || !(t.amount > 0) || !String(t.desc || '').trim()) bad.push(t.id);
      });
    });
    add('数据格式：日期 / 金额 / 描述', bad.length ? 'fail' : 'pass',
      bad.length ? bad.length + ' 笔异常，例如 ' + bad.slice(0, 3).join('、') : '全部 ' + scanned + ' 笔通过');

    /* 2 官方样本完整与去重（导入的独立数据集不计入官方样本） */
    var total = 0, raw = 0, dup = 0;
    DS.forEach(function (d) {
      if (d.custom) return;
      total += d.txns.length; raw += num(d.totals.raw_rows); dup += num(d.totals.dup_removed);
    });
    add('官方样本完整与去重', (total === 692 && raw - dup === total) ? 'pass' : 'fail',
      '原始 ' + raw + ' 笔 − 重复 ' + dup + ' 笔 = ' + total + ' 笔（期望 692）');

    /* 3 分类覆盖：兜底占比 */
    var fb = all.filter(function (t) { return t.engine === 'fallback'; }).length;
    var cover = all.length ? 1 - fb / all.length : 0;
    add('分类覆盖（非兜底占比）', cover >= 0.9 ? 'pass' : (cover >= 0.7 ? 'warn' : 'fail'),
      (cover * 100).toFixed(1) + '% · 兜底 ' + fb + ' / ' + all.length + ' 笔' +
      (fb ? '（兜底多为新词，可补关键词）' : ''));

    /* 4 逐月对账：明细合计 = 月度汇总 */
    var reconBad = [], maxDiff = 0, monthCnt = 0;
    DS.forEach(function (d) {
      var msum = {};
      d.txns.forEach(function (t) {
        if (t.type !== '支出') return;
        msum[t.month] = r2((msum[t.month] || 0) + t.amount);
      });
      d.recon.forEach(function (r) {
        monthCnt += 1;
        maxDiff = Math.max(maxDiff, Math.abs(r2((msum[r.month] || 0) - r.clean)), Math.abs(num(r.diff)));
        if (Math.abs(r2((msum[r.month] || 0) - r.clean)) > 0.005) reconBad.push(d.id + ' ' + r.month);
      });
    });
    add('逐月对账：支出明细 = 月度汇总', reconBad.length ? 'fail' : 'pass',
      monthCnt + ' 个月 · 最大差额 ' + maxDiff.toFixed(2) + ' 元' + (reconBad.length ? '，异常：' + reconBad.join('、') : ''));

    /* 5 固定 + 弹性 = 总支出 */
    var fs = fixedSplit(cur);
    add('固定 + 弹性 = 总支出', Math.abs(r2(fs.fixed + fs.flex) - fs.total) < 0.005 ? 'pass' : 'fail',
      fmt(fs.fixed) + ' + ' + fmt(fs.flex) + ' = ' + fmt(fs.total) + ' 元');

    /* 6 结余 = 收入 − 支出（逐月） */
    var badBal = [];
    monthKeys(ds).forEach(function (m) {
      var t = totalsOf(all.filter(function (x) { return x.month === m; }));
      if (Math.abs(r2(t.income - t.expense) - t.balance) > 0.005) badBal.push(m);
    });
    add('结余 = 收入 − 支出', badBal.length ? 'fail' : 'pass',
      monthKeys(ds).length + ' 个月逐月复算' + (badBal.length ? '，异常：' + badBal.join('、') : '一致'));

    /* 7 瀑布闭合：上月合计 + 分类增减 = 本月合计 */
    var ms = monthKeys(ds);
    var wi = state.month ? ms.indexOf(state.month) : -1;
    if (wi <= 0) {
      add('瀑布闭合：上月 + 增减 = 本月', 'skip', '当前为最早月份，无上月数据');
    } else {
      var pm = {}, cm = {};
      expenseByCat(all.filter(function (t) { return t.month === ms[wi - 1]; })).forEach(function (r) { pm[r.cat] = r.amount; });
      expenseByCat(all.filter(function (t) { return t.month === ms[wi]; })).forEach(function (r) { cm[r.cat] = r.amount; });
      var names = {};
      Object.keys(pm).concat(Object.keys(cm)).forEach(function (c) { names[c] = 1; });
      var pT = sum(Object.keys(pm).map(function (c) { return pm[c]; }));
      var cT = sum(Object.keys(cm).map(function (c) { return cm[c]; }));
      var dT = sum(Object.keys(names).map(function (c) { return r2((cm[c] || 0) - (pm[c] || 0)); }));
      add('瀑布闭合：上月 + 增减 = 本月', Math.abs(r2(pT + dT) - cT) < 0.005 ? 'pass' : 'fail',
        fmt(pT) + ' + ' + fmt(dT) + ' = ' + fmt(cT) + ' 元');
    }

    /* 8 异常规则复算 */
    var byTruth = {}, byPred = {};
    all.forEach(function (t) {
      if (t.type !== '支出') return;
      (byTruth[t.truth || t.cat] = byTruth[t.truth || t.cat] || []).push(t.amount);
      (byPred[t.cat] = byPred[t.cat] || []).push(t.amount);
    });
    var mism = [];
    all.forEach(function (t) {
      if (t.type !== '支出') return;
      var pool = t.source === 'data' ? byTruth[t.truth || t.cat] : byPred[t.cat];
      var med = median(pool || [t.amount]);
      var hit = t.amount >= Math.max(500, med * 2.5) || /疑似大额异常/.test(t.note || '');
      if (hit !== !!t.isOutlier) mism.push(t.id);
    });
    var anomalyN = all.filter(function (t) { return t.type === '支出' && t.isOutlier; }).length;
    add('异常规则复算', mism.length ? 'fail' : 'pass',
      anomalyN + ' 笔命中' + (mism.length ? '，' + mism.length + ' 笔标记不一致：' + mism.slice(0, 3).join('、') : '，逐笔复算一致'));

    /* 9 预算覆盖与超支复算 */
    var brows = budgetRows(ds);
    var expCats = expenseByCat(cur).map(function (r) { return r.cat; });
    var missing = expCats.filter(function (c) { return !ds.budget[c]; });
    var overBad = brows.filter(function (r) { return Math.abs(r.over - r2(Math.max(0, r.actual - r.budget))) > 0.005; }).length;
    add('预算覆盖全部支出分类', missing.length ? 'warn' : (overBad ? 'fail' : 'pass'),
      brows.length + ' 个预算分类' + (missing.length ? '，缺预算：' + missing.join('、') : '，全部覆盖') +
      '；超支额复算' + (overBad ? '不一致' : '一致'));

    /* 10 模型参数与评测记录 */
    var e = DATA.eval || {};
    var m = DATA.model || {};
    var priorSum = Object.keys(m.priors || {}).reduce(function (s, k) { return s + num(m.priors[k]); }, 0);
    var folds = e.fold_accuracies || [];
    var mean = folds.length ? sum(folds) / folds.length : 0;
    var modelOk = !!m.labels && Math.abs(priorSum - 1) < 0.005 && folds.length === num(e.cv_k) &&
      Math.abs(mean - num(e.model_accuracy)) < 0.001;
    add('模型参数与评测记录', modelOk ? 'pass' : 'fail',
      '先验合计 ' + priorSum.toFixed(3) + ' · ' + folds.length + ' 折 · 均值 ' + pct(mean) + '（记录 ' + pct(e.model_accuracy) + '）');

    /* 11 网络请求计数 */
    var netEl = document.getElementById('netCount');
    var net = netEl ? num(netEl.textContent) : 0;
    add('网络请求计数', net === 0 ? 'pass' : 'fail', '本轮跨源请求 ' + net + ' 次（本地脚本不计）');

    var ico = { pass: '✓', warn: '!', fail: '×', skip: '–' };
    box.innerHTML = '<p class="check-meta">当前数据集 ' + esc(ds.name || ds.id) + ' · 统计月份 ' +
      esc(state.month || '全部') + ' · 含页面新增 ' + (state.manual[ds.id] || []).length + ' 笔</p>' +
      checks.map(function (c) {
        return '<div class="check-row ' + c.status + '"><span class="ck-ico">' + ico[c.status] +
          '</span><span class="ck-name">' + esc(c.name) + '</span><span class="ck-detail">' + esc(c.detail) + '</span></div>';
      }).join('');

    if (badge) {
      /* 以实际渲染出的行为准，避免跳过项被算成「全部通过」 */
      var passN = box.querySelectorAll('.check-row.pass').length;
      var fails = box.querySelectorAll('.check-row.fail').length;
      var warns = box.querySelectorAll('.check-row.warn').length;
      var skips = box.querySelectorAll('.check-row.skip').length;
      badge.className = 'head-badge' + (fails ? ' bad' : (warns ? ' warn' : ''));
      badge.textContent = fails ? fails + ' 项未通过' + (warns ? ' · ' + warns + ' 需关注' : '') :
        (warns ? passN + ' 通过 · ' + warns + ' 需关注' :
          passN + ' 项通过' + (skips ? ' · ' + skips + ' 项不适用' : ''));
    }
    return checks;
  }

  /* ============ 明细 ============ */

  function detailRows() {
    var ds = getDs();
    var q = state.filters.q.trim().toLowerCase();
    return allTxns(ds).filter(function (t) {
      if (state.filters.type && t.type !== state.filters.type) return false;
      if (state.filters.month && t.month !== state.filters.month) return false;
      if (state.filters.cat && t.cat !== state.filters.cat) return false;
      if (q) {
        var hay = (t.desc + ' ' + t.cat + ' ' + t.account + ' ' + t.id).toLowerCase();
        if (hay.indexOf(q) < 0) return false;
      }
      return true;
    }).sort(function (a, b) {
      return a.date === b.date ? (a.id < b.id ? 1 : -1) : (a.date < b.date ? 1 : -1);
    });
  }

  function renderDetail() {
    var tbl = document.getElementById('detailTable');
    if (!tbl) return;
    var rows = detailRows();
    var meta = document.getElementById('tableMeta');
    if (meta) {
      var e = sum(rows.filter(function (t) { return t.type === '支出'; }).map(function (t) { return t.amount; }));
      var i = sum(rows.filter(function (t) { return t.type === '收入'; }).map(function (t) { return t.amount; }));
      meta.textContent = '共 ' + rows.length + ' 笔 · 支出 ' + fmt(e) + ' 元 · 收入 ' + fmt(i) + ' 元';
    }
    tbl.innerHTML = '<thead><tr><th>日期</th><th>类型</th><th class="wrap">描述</th><th>分类</th><th>规则强度</th><th class="num">金额(元)</th><th>命中词</th><th>账户</th><th>来源</th><th>标记</th></tr></thead><tbody>' +
      rows.map(function (t) {
        var st = ruleStrength(t.desc, t.type);
        var stCls = st.level === '强' ? 'income' : (st.level === '中' ? 'gray' : 'amber');
        return '<tr>' +
          '<td>' + esc(t.date) + '</td>' +
          '<td><span class="pill ' + (t.type === '收入' ? 'income' : 'expense') + '">' + esc(t.type) + '</span></td>' +
          '<td class="wrap" title="' + esc(t.note) + '">' + esc(t.desc) + '</td>' +
          '<td><span class="rank-dot" style="display:inline-block;background:' + (COLORS[t.cat] || '#8b98a0') + ';margin-right:6px"></span>' + esc(t.cat) + '</td>' +
          '<td><span class="pill ' + stCls + '" title="命中 ' + st.hits + ' 个关键词">' + st.level + '</span></td>' +
          '<td class="num">' + fmt(t.amount) + '</td>' +
          '<td>' + (t.keyword ? '<span class="pill gray">' + esc(t.keyword) + '</span>' : '<span class="dim">—</span>') + '</td>' +
          '<td>' + esc(t.account || '—') + '</td>' +
          '<td>' + (t.source === 'data' ? '<span class="dim">账单</span>' : '<span class="pill amber">页面新增</span>') + '</td>' +
          '<td>' + (t.isOutlier ? '<span class="pill expense">异常</span>' : '') +
          (t.corrected ? '<span class="pill amber">已校正</span>' : '') +
          (!t.isOutlier && !t.corrected ? '<span class="dim">—</span>' : '') + '</td></tr>';
      }).join('') + '</tbody>';
    if (!rows.length) {
      tbl.innerHTML = '<tbody><tr><td class="dim" style="padding:26px;text-align:center">没有符合条件的记录</td></tr></tbody>';
    }
  }

  function syncFilterInputs() {
    var s = document.getElementById('searchInput');
    if (s) s.value = state.filters.q;
    var t = document.getElementById('filterType');
    if (t) t.value = state.filters.type;
    var m = document.getElementById('filterMonth');
    if (m) m.value = state.filters.month;
    var c = document.getElementById('filterCategory');
    if (c) c.value = state.filters.cat;
  }

  function drill(cat) {
    state.filters = { q: '', type: '支出', month: state.month || '', cat: cat || '' };
    syncFilterInputs();
    showTab('detail');
    toast('已筛选分类：' + (cat || '全部') + ' · ' + monthLabel(state.month));
  }

  /* ============ 对照 ============ */
  function renderCompare() {
    var ds = getDs();
    var note = document.getElementById('compareNote');
    var tbl = document.getElementById('compareTable');
    if (ds.custom) {
      if (note) note.innerHTML = '当前为导入数据集「' + esc(ds.name) + '」，未做统计局八大类映射，本页不做官方口径对照；切回 D1 / D2 / D3 可查看对照结果。';
      clearChart('chartCompare', '导入数据集暂不做八大类对照');
      if (tbl) tbl.innerHTML = '<tbody><tr><td class="dim">导入数据集暂不做八大类对照</td></tr></tbody>';
      return;
    }
    var ins = DATA.insight && DATA.insight.datasets && DATA.insight.datasets[ds.id];
    var bm = (DATA.insight && DATA.insight.benchmark) || {};
    if (note) {
      note.innerHTML = bm.source
        ? '官方基准：' + esc(bm.period || '') + '　来源：<code>' + esc(bm.source) + '</code><br>口径说明：本账单占比按映射表归入统计局八大类；样本为脱敏模拟数据，仅用于结构对照，不代表居民总体，也不构成因果结论。'
        : '暂无官方基准数据。';
    }
    if (!ins || !ins.eight_category) {
      if (tbl) tbl.innerHTML = '<tbody><tr><td class="dim">暂无对照数据</td></tr></tbody>';
      return;
    }
    var rows = ins.eight_category;
    var ax = axisStyle();
    draw('chartCompare', {
      color: ['#0e6b4f', '#2f7bd6', '#e0a30a', '#9b59b6'],
      tooltip: {
        trigger: 'axis', confine: true, axisPointer: { type: 'shadow' },
        valueFormatter: function (v) { return (v * 100).toFixed(1) + '%'; }
      },
      legend: { data: ['本账单', '全国', '城镇', '农村'], bottom: 0, icon: 'roundRect', itemWidth: 9, itemHeight: 9, textStyle: { fontSize: 11, color: '#728a81' } },
      grid: { left: 4, right: 14, top: 22, bottom: 56, containLabel: true },
      xAxis: { type: 'category', data: rows.map(function (r) { return r.cat; }), ...ax, axisLabel: { fontSize: 11, color: '#728a81', interval: 0, rotate: 16 } },
      yAxis: { type: 'value', splitLine: ax.splitLine, axisLabel: { fontSize: 11, color: '#728a81', formatter: function (v) { return (v * 100).toFixed(0) + '%'; } } },
      series: [
        { name: '本账单', type: 'bar', barMaxWidth: 22, itemStyle: { borderRadius: [4, 4, 0, 0] }, data: rows.map(function (r) { return r.mine; }) },
        { name: '全国', type: 'bar', barMaxWidth: 22, itemStyle: { borderRadius: [4, 4, 0, 0] }, data: rows.map(function (r) { return r.national; }) },
        { name: '城镇', type: 'bar', barMaxWidth: 22, itemStyle: { borderRadius: [4, 4, 0, 0] }, data: rows.map(function (r) { return r.urban; }) },
        { name: '农村', type: 'bar', barMaxWidth: 22, itemStyle: { borderRadius: [4, 4, 0, 0] }, data: rows.map(function (r) { return r.rural; }) }
      ]
    });
    if (tbl) {
      tbl.innerHTML = '<thead><tr><th>统计局八大类</th><th class="num">本账单金额</th><th class="num">本账单占比</th><th class="num">全国</th><th class="num">城镇</th><th class="num">农村</th><th class="num">与全国差值</th></tr></thead><tbody>' +
        rows.map(function (r) {
          var d = r.mine - r.national;
          return '<tr><td>' + esc(r.cat) + '</td><td class="num">' + fmt(r.mine_amount) + '</td><td class="num">' + pct(r.mine) +
            '</td><td class="num">' + pct(r.national) + '</td><td class="num">' + pct(r.urban) + '</td><td class="num">' + pct(r.rural) +
            '</td><td class="num" style="color:' + (Math.abs(d) > 0.05 ? (d > 0 ? '#b3352c' : '#0e6b4f') : '#728a81') + '">' +
            (d > 0 ? '+' : '') + (d * 100).toFixed(1) + 'pp</td></tr>';
        }).join('') + '</tbody>';
    }
  }

  /* ============ 录入 ============ */
  function classify(desc, type) {
    var text = String(desc || '').toLowerCase();
    var rules = type === '收入' ? INCOME_RULES : EXPENSE_RULES;
    for (var i = 0; i < rules.length; i++) {
      for (var j = 0; j < rules[i][1].length; j++) {
        if (text.indexOf(rules[i][1][j]) >= 0) {
          return { cat: rules[i][0], keyword: rules[i][1][j], conf: 0.97, engine: 'rule' };
        }
      }
    }
    return { cat: RULES.fallback[type] || (type === '收入' ? '工资收入' : '其他'), keyword: '兜底', conf: 0.55, engine: 'fallback' };
  }

  /* 规则强度：命中 2 个以上关键词＝强，1 个＝中，走兜底＝弱。可解释，不冒充概率。 */
  function ruleStrength(desc, type) {
    var text = String(desc || '').toLowerCase();
    var rules = type === '收入' ? INCOME_RULES : EXPENSE_RULES;
    for (var i = 0; i < rules.length; i++) {
      var hits = rules[i][1].filter(function (kw) { return text.indexOf(kw) >= 0; });
      if (hits.length) return { level: hits.length >= 2 ? '强' : '中', hits: hits.length };
    }
    return { level: '弱', hits: 0 };
  }

  function pad(n) { return String(n).padStart(2, '0'); }
  function ymd(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function iso(y, m, d) { return y + '-' + pad(Number(m)) + '-' + pad(Number(d)); }

  function toISODate(text, ref) {
    var s = String(text || '');
    var m = s.match(/(20\d{2})[年\/\-](\d{1,2})[月\/\-](\d{1,2})/);
    if (m) return iso(m[1], m[2], m[3]);
    var r = new Date((ref || ANCHOR_DATE).getTime());
    if (s.indexOf('前天') >= 0) { r.setDate(r.getDate() - 2); return ymd(r); }
    if (s.indexOf('昨天') >= 0) { r.setDate(r.getDate() - 1); return ymd(r); }
    if (s.indexOf('今天') >= 0) return ymd(r);
    if (s.indexOf('上周五') >= 0) {
      var day = r.getDay();
      var delta = day >= 5 ? day - 5 + 7 : day + 2;
      r.setDate(r.getDate() - delta);
      return ymd(r);
    }
    m = s.match(/(\d{1,2})月(\d{1,2})[日号]?/);
    if (m) return iso(r.getFullYear(), m[1], m[2]);
    m = s.match(/(?:^|\D)(\d{1,2})[日号]/);
    if (m) return iso(r.getFullYear(), r.getMonth() + 1, m[1]);
    return ymd(r);
  }

  function stripDates(text) {
    return String(text || '')
      .replace(/20\d{2}\s*年?\s*\d{1,2}\s*月\s*\d{1,2}\s*[日号]?/g, ' ')
      .replace(/\d{1,2}\s*月\s*\d{1,2}\s*[日号]?/g, ' ')
      .replace(/(今天|昨天|前天|大前天|上周[一二三四五六日天]|本周[一二三四五六日天])/g, ' ')
      .replace(/\d{1,2}\s*[日号]/g, ' ');
  }

  function parseAmount(text) {
    /* 先剥掉日期片段，避免“2025 年 11 月 5 日”里的 5 被当成金额（与 nl_parse.py 一致） */
    var s = stripDates(text);
    var unit = s.match(/(\d+(?:\.\d+)?)\s*(?:元|块钱|块|rmb)/i);
    if (unit) return Number(unit[1]);
    var all = s.match(/\d+(?:\.\d+)?/g);
    return all && all.length ? Number(all[all.length - 1]) : NaN;
  }

  function inferType(text) {
    /* 与 nl_parse.py 的 infer_type 对齐：有支出词即判支出，避免“买了东西退款”被判成收入 */
    var s = String(text || '');
    var income = INCOME_WORDS.some(function (w) { return s.indexOf(w) >= 0; });
    var spend = SPEND_WORDS.some(function (w) { return s.indexOf(w) >= 0; });
    return income && !spend ? '收入' : '支出';
  }

  function cleanDesc(text) {
    /* 与 nl_parse.py 的 clean_desc 对齐：先去掉日期与金额，描述里不残留“11月5日” */
    return stripDates(text)
      .replace(/(\d+(?:\.\d+)?)\s*(?:元|块钱|块|rmb)/gi, ' ')
      .replace(/\d+(?:\.\d+)?/g, ' ')
      .replace(/[，。,.、:：;；]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim() || '未命名交易';
  }

  function makeRecord(o) {
    state.uid += 1;
    return {
      id: 'M-' + state.uid, date: o.date, month: o.date.slice(0, 7), type: o.type,
      amount: r2(o.amount), desc: o.desc, cat: o.cat, truth: '', sub: '', account: o.account || '手工录入',
      pay: '未指定', note: o.note || '页面录入', isOutlier: false,
      keyword: o.keyword || '', conf: o.conf || 0.55, engine: o.engine || 'rule', source: o.source || 'manual'
    };
  }

  function markOutliers(ds) {
    var exp = allTxns(ds).filter(function (t) { return t.type === '支出'; });
    var byCat = {};
    exp.forEach(function (t) {
      if (!byCat[t.cat]) byCat[t.cat] = [];
      byCat[t.cat].push(t.amount);
    });
    exp.forEach(function (t) {
      if (t.source === 'data') return;
      var arr = (byCat[t.cat] || []).slice().sort(function (a, b) { return a - b; });
      var med = arr.length ? (arr.length % 2 ? arr[(arr.length - 1) / 2] : (arr[arr.length / 2 - 1] + arr[arr.length / 2]) / 2) : t.amount;
      t.isOutlier = t.amount >= Math.max(500, med * 2.5);
    });
  }

  function addRecords(list, label) {
    var ds = getDs();
    if (!list.length) { toast('没有可写入的记录'); return; }
    Array.prototype.push.apply(state.manual[ds.id], list);
    /* 跳到新增记录所在月份，避免写进去却在当前月份看不到 */
    var mx = '';
    list.forEach(function (t) { if (t.month && t.month > mx) mx = t.month; });
    if (mx && mx !== state.month) state.month = mx;
    markOutliers(ds);
    writeStore();
    renderAll();
    toast(label + '：' + list.length + ' 笔已并入 ' + ds.id + (mx ? '（' + monthLabel(mx) + '）' : ''));
  }

  function parseBatch(text) {
    var out = [], errors = [];
    var lines = String(text || '').split(/\r?\n/).map(function (s) { return s.trim(); })
      .filter(function (s) { return s && s.charAt(0) !== '#'; });
    lines.forEach(function (line, li) {
      var body = line, ctxRef = null;
      var pre = line.match(/^(?:(?:20\d{2})[年\/\-]\d{1,2}[月\/\-]\d{1,2}[日号]?|\d{1,2}月\d{1,2}[日号]?|今天|昨天|前天|上周[一二三四五六日天])\s*[：:]\s*/);
      if (pre) {
        body = line.slice(pre[0].length);
        ctxRef = new Date(toISODate(pre[0], ANCHOR_DATE) + 'T12:00:00');
      }
      var segs = body.split(/[；;]/).map(function (s) { return s.trim(); }).filter(Boolean);
      var prevRef = ctxRef;
      segs.forEach(function (seg, si) {
        var amount = parseAmount(seg);
        if (!isFinite(amount) || amount <= 0) {
          errors.push('第' + (li + 1) + '行第' + (si + 1) + '段未识别到金额：' + seg);
          return;
        }
        var date = toISODate(seg, prevRef || ANCHOR_DATE);
        var type = inferType(seg);
        var c = classify(seg, type);
        out.push({ date: date, amount: r2(amount), type: type, desc: cleanDesc(seg), cat: c.cat, keyword: c.keyword, conf: c.conf });
        prevRef = new Date(date + 'T12:00:00');
      });
    });
    return { items: out, errors: errors };
  }

  function recordFrom(o, source) {
    return makeRecord({
      date: o.date, type: o.type, amount: o.amount, desc: o.desc, cat: o.cat,
      keyword: o.keyword, conf: o.conf, source: source, note: source === 'batch' ? '批量录入' : source === 'csv' ? 'CSV 导入' : '自然语言录入'
    });
  }

  function renderEntry() {
    var anchorLabel = document.getElementById('anchorLabel');
    if (anchorLabel) anchorLabel.textContent = ANCHOR + '（今天）';

    var ds = getDs();
    var box = document.getElementById('manualList');
    if (box) {
      var list = (state.manual[ds.id] || []).slice().reverse();
      if (!list.length) {
        box.innerHTML = '<div class="empty">本次还没有新增记录</div>';
      } else {
        box.innerHTML = list.map(function (t) {
          return '<div class="manual-item" data-del="' + esc(t.id) + '">' +
            '<div class="m-main"><span class="m-date">' + esc(t.date) + '</span><b>' + esc(t.desc) + '</b> · ' +
            esc(t.cat) + ' · ' + esc(t.type) + ' · <b>' + fmt(t.amount) + '</b> 元</div>' +
            '<button type="button" title="删除">删除</button></div>';
        }).join('');
      }
    }
    renderNl();
  }

  function renderNl() {
    var tbl = document.getElementById('nlTable');
    if (!tbl) return;
    var nl = DATA.nl;
    if (!nl || !nl.batches) {
      tbl.innerHTML = '<tbody><tr><td class="dim">暂无解析结果</td></tr></tbody>';
      return;
    }
    var card = tbl.closest('.card');
    var s = nl.selfcheck || {};
    if (card && !card.querySelector('.nl-selfcheck')) {
      var d = document.createElement('div');
      d.className = 'nl-selfcheck';
      card.insertBefore(d, card.querySelector('.table-wrap'));
    }
    var sc = card && card.querySelector('.nl-selfcheck');
    if (sc) {
      sc.innerHTML = '批次 <b>' + (nl.batch_count || 0) + '</b> 个 · 解析 <b>' + (nl.batch_items || 0) +
        '</b> 笔　143 条自测：日期 <b>' + (num(s.date_acc) * 100).toFixed(1) + '%</b> · 金额 <b>' +
        (num(s.amount_acc) * 100).toFixed(1) + '%</b> · 分类 <b>' + (num(s.category_acc) * 100).toFixed(1) + '%</b>' +
        (nl.note ? '　<span class="dim">' + esc(nl.note) + '</span>' : '');
    }
    var rows = [];
    (nl.batches || []).forEach(function (b) {
      (b.items || []).forEach(function (it) {
        rows.push('<tr><td>' + b.batch_no + '</td><td>' + esc(it.date) + '</td><td class="wrap">' + esc(it.raw || it.desc) +
          '</td><td>' + esc(it.type) + '</td><td class="num">' + fmt(it.amount) + '</td><td>' + esc(it.pred) +
          '</td><td>' + (it.rule_hit ? '<span class="pill gray">' + esc(it.rule_hit) + '</span>' : '—') + '</td></tr>');
      });
    });
    tbl.innerHTML = '<thead><tr><th>批次</th><th>日期</th><th class="wrap">原始片段</th><th>类型</th><th class="num">金额</th><th>预测分类</th><th>命中词</th></tr></thead><tbody>' +
      (rows.length ? rows.join('') : '<tr><td class="dim" colspan="7">暂无解析结果</td></tr>') + '</tbody>';
  }

  /* ============ 报告 ============ */
  function renderReport() {
    var sheet = document.getElementById('reportSheet');
    if (!sheet) return;
    var ds = getDs();
    var tx = monthTxns(ds);
    var t = totalsOf(tx);
    var rows = expenseByCat(tx);
    var br = budgetRows(ds);
    var an = tx.filter(function (x) { return x.type === '支出' && x.isOutlier; });
    var ins = DATA.insight && DATA.insight.datasets && DATA.insight.datasets[ds.id];
    var lines = (ins && ((ins.monthly_summaries && state.month && ins.monthly_summaries[state.month]) || ins.summary)) || [];
    if (!lines.length && ds.custom) {
      var topCat = rows[0];
      lines = ['本月共 ' + tx.length + ' 笔交易，支出 ' + fmt(t.expense) + ' 元，收入 ' + fmt(t.income) +
        ' 元，结余 ' + fmt(t.balance) + ' 元。'];
      if (topCat) lines.push('支出最多的是「' + topCat.cat + '」，' + fmt(topCat.amount) + ' 元，占本月支出 ' +
        pct(topCat.amount / (t.expense || 1)) + '。');
      if (an.length) lines.push('有 ' + an.length + ' 笔支出触发异常规则，已在下方列出。');
      lines.push('本数据集由 CSV 导入生成，分类由「描述」经规则引擎判定；以上为描述性统计，不做因果推断。');
    }
    var reconOk = (ds.recon || []).every(function (r) { return Math.abs(num(r.diff)) < 0.005; });
    var rv = reviewStats(ds);
    var bov = Object.keys(state.budgetOverride[ds.id] || {}).length;
    var fs = fixedSplit(tx);
    var ev = DATA.eval || {};

    sheet.innerHTML =
      '<div class="rp-head"><div><div class="rp-title">账本有数 · 收支分析报告</div>' +
      '<div class="rp-sub">' + esc(ds.name) + '账单 · ' + esc(monthLabel(state.month)) + ' · 共 ' + tx.length + ' 笔交易</div></div>' +
      '<div class="rp-stamp">生成时间 ' + new Date().toLocaleString('zh-CN') + '<br>数据仅在本机浏览器内计算<br>网络请求 0 次</div></div>' +
      '<div class="rp-kpis">' +
      '<div class="rp-kpi"><span>支出</span><b>' + fmt(t.expense) + '</b></div>' +
      '<div class="rp-kpi"><span>收入</span><b>' + fmt(t.income) + '</b></div>' +
      '<div class="rp-kpi"><span>结余</span><b>' + fmt(t.balance) + '</b></div>' +
      '<div class="rp-kpi"><span>异常支出</span><b>' + an.length + ' 笔</b></div></div>' +
      '<div class="rp-sec"><h4>一、月度小结</h4>' + (lines.length ? lines.map(function (s) {
        var dis = s.indexOf('描述性统计') >= 0;
        return '<div class="rp-line' + (dis ? ' disclaimer' : '') + '">' + (dis ? '' : '· ') + esc(s) + '</div>';
      }).join('') : '<div class="rp-line">暂无小结</div>') + '</div>' +
      '<div class="rp-sec"><h4>二、支出结构（前 6 类）</h4>' +
      '<table class="tbl"><thead><tr><th>分类</th><th class="num">金额(元)</th><th class="num">占比</th></tr></thead><tbody>' +
      (rows.length ? rows.slice(0, 6).map(function (r) {
        return '<tr><td>' + esc(r.cat) + '</td><td class="num">' + fmt(r.amount) + '</td><td class="num">' + pct(r.amount / (t.expense || 1)) + '</td></tr>';
      }).join('') + '<tr class="total"><td>支出合计</td><td class="num">' + fmt(t.expense) + '</td><td class="num">100.0%</td></tr>'
        : '<tr><td colspan="3">本月无支出</td></tr>') + '</tbody></table></div>' +
      '<div class="rp-sec"><h4>三、固定 / 弹性支出</h4>' +
      (fs.total ? '<table class="tbl"><thead><tr><th>类型</th><th class="num">金额(元)</th><th class="num">占比</th></tr></thead><tbody>' +
        '<tr><td>固定支出（居住 / 通讯 / 交通）</td><td class="num">' + fmt(fs.fixed) + '</td><td class="num">' + pct(fs.fixedShare) + '</td></tr>' +
        '<tr><td>弹性支出（可压缩部分）</td><td class="num">' + fmt(fs.flex) + '</td><td class="num">' + pct(fs.flexShare) + '</td></tr>' +
        '<tr class="total"><td>支出合计</td><td class="num">' + fmt(fs.total) + '</td><td class="num">100.0%</td></tr></tbody></table>' +
        '<div class="rp-line">固定支出覆盖收入 ' + (fs.cover ? pct(fs.cover) : '—') + '；弹性支出是本月的可调整空间。</div>'
        : '<div class="rp-line">本月无支出，无法拆分固定 / 弹性。</div>') + '</div>' +
      '<div class="rp-sec"><h4>四、预算执行</h4>' +
      '<table class="tbl"><thead><tr><th>分类</th><th class="num">预算</th><th class="num">实际</th><th class="num">执行率</th><th>状态</th></tr></thead><tbody>' +
      (br.length ? br.map(function (r) {
        return '<tr><td>' + esc(r.cat) + '</td><td class="num">' + fmt(r.budget) + '</td><td class="num">' + fmt(r.actual) +
          '</td><td class="num">' + r.pct.toFixed(1) + '%</td><td>' + r.status + '</td></tr>';
      }).join('') : '<tr><td colspan="5">未配置预算</td></tr>') + '</tbody></table></div>' +
      '<div class="rp-sec"><h4>五、异常支出</h4>' +
      (an.length ? '<table class="tbl"><thead><tr><th>日期</th><th>描述</th><th>分类</th><th class="num">金额(元)</th><th class="num">同类中位数</th></tr></thead><tbody>' +
        an.map(function (x) {
          var arr = [];
          allTxns(ds).forEach(function (y) { if (y.type === '支出' && y.cat === x.cat) arr.push(y.amount); });
          return '<tr><td>' + esc(x.date) + '</td><td>' + esc(x.desc) + '</td><td>' + esc(x.cat) + '</td><td class="num">' + fmt(x.amount) +
            '</td><td class="num">' + fmt(median(arr)) + '</td></tr>';
        }).join('') + '</tbody></table>'
        : '<div class="rp-line">本月没有触发异常规则的支出。</div>') + '</div>' +
      '<div class="rp-sec"><h4>六、对账结果</h4><div class="rp-line">' +
      (reconOk ? '明细逐笔汇总与月度汇总逐月核对，全部差额为 0.00。' : '存在未对平的月份，请检查明细。') + '</div></div>' +
      '<div class="rp-sec"><h4>七、人工复核与预算调整</h4><div class="rp-line">' +
      '双引擎分歧 ' + rv.disagree + ' 笔，已人工确认 ' + rv.resolved + ' 笔（采用模型 ' + rv.adoptModel +
      ' 笔，维持规则 ' + rv.adoptRule + ' 笔，其他 ' + rv.custom + ' 笔）。' +
      (bov ? '预算调整：' + bov + ' 个分类使用自定义月预算。' : '预算：使用默认配置。') + '</div></div>' +
      '<div class="rp-foot">口径说明：分类由「描述」字段经规则引擎判定（离线评测规则准确率 ' + pct(ev.rule_accuracy || 0) +
      '，朴素贝叶斯 ' + (ev.cv_k || 5) + ' 折交叉验证 ' + pct(ev.model_accuracy || 0) + ' ± ' +
      (num(ev.model_accuracy_std) * 100).toFixed(2) + ' 个百分点），未使用一级/二级分类与备注作为输入特征。<br>' +
      '免责声明：本报告仅为账单数据的描述性统计，不代表因果结论，也不构成任何投资或消费建议。数据为脱敏模拟数据，源自赛题发放包。</div>';
  }

  /* ============ 渲染调度 ============ */
  function renderAll() {
    renderDsSwitch();
    renderMonthSelect();
    renderHeadBadges();
    renderKpi();
    renderPieMini();
    renderOverviewTrend();
    renderSummary();
    renderStructure();
    renderFixed();
    renderTrend();
    renderSavings();
    renderWaterfall();
    renderRecon();
    renderBudget();
    renderAnomaly();
    renderAccount();
    renderReview();
    renderEval();
    renderDetail();
    renderEntry();
    renderCompare();
    renderReport();
    runSelfCheck();
    setTimeout(function () {
      Object.keys(state.charts).forEach(function (k) {
        var el = document.getElementById(k);
        if (el && el.clientWidth > 0) state.charts[k].resize();
      });
    }, 60);
  }

  function showTab(tab) {
    state.tab = tab;
    var tabs = document.querySelectorAll('#tabs button');
    Array.prototype.forEach.call(tabs, function (b) {
      b.classList.toggle('active', b.getAttribute('data-tab') === tab);
    });
    var views = document.querySelectorAll('main > .view');
    Array.prototype.forEach.call(views, function (v) {
      v.hidden = v.id !== 'view-' + tab;
    });
    renderAll();
    var act = document.querySelector('#tabs button.active');
    if (act && act.scrollIntoView) act.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    syncTabsHint();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* ============ 数据集切换 ============ */
  function switchDs(id, quiet) {
    if (id && DS.some(function (d) { return d.id === id; })) state.ds = id;
    var ds = getDs();
    state.month = latestMonth(ds) || '';
    state.filters = { q: '', type: '', month: '', cat: '' };
    syncFilterInputs();
    renderAll();
    if (!quiet) toast('已切换到 ' + ds.id + ' · ' + ds.name);
  }

  /* ============ 3 分钟演示剧本 ============ */
  var TOUR = [
    { tab: 'overview', sel: '#kpiGrid', title: '概览：每个数字都能回到明细', text: '支出、收入、结余、预算、异常全部由明细逐笔汇总，点击任意卡片可下钻到对应页签。' },
    { tab: 'structure', sel: '#fixedCard', title: '结构：先分清“必须花”和“可以省”', text: '固定支出＝居住 / 通讯 / 交通；其余为弹性支出，是本月真正可压缩的部分。' },
    { tab: 'trend', sel: '#chartWaterfall', title: '趋势：环比涨跌一眼看清', text: '瀑布图把本月与上月的差额拆到每个分类，结余率走势同时看金额与比例。' },
    { tab: 'budget', sel: '#budgetList', title: '预算：改一个数，全站立刻重算', text: '月预算可直接行内编辑，预警线、超支分类与报告同步更新。' },
    { tab: 'anomaly', sel: '#anomalyList', title: '异常：给金额补上上下文', text: '每张卡显示同类中位数、倍数，以及剔除本笔后的本月支出，避免“只看大数字”。' },
    { tab: 'review', sel: '#evalKpi', title: '复核：双引擎 + 离线评测', text: '规则与朴素贝叶斯不一致的交易人工确认；5 折交叉验证给出模型的真实水平与波动。' },
    { tab: 'entry', sel: '#singleInput', title: '录入：一句话记一笔', text: '“昨天午饭 25 元”即可解析日期、金额、类型与分类，结果当场给出规则强度。' },
    { tab: 'report', sel: '#reportSheet', title: '报告：一键导出可打印结论', text: '报告汇总固定/弹性拆分、预算、异常、对账与复核，可直接打印或存为 PDF。' }
  ];
  var tourIdx = 0;

  function clearFocus() {
    Array.prototype.forEach.call(document.querySelectorAll('.tour-focus'), function (el) {
      el.classList.remove('tour-focus');
    });
  }

  function renderTour() {
    var step = TOUR[tourIdx];
    if (!step) return;
    var stepEl = document.getElementById('tourStep');
    var textEl = document.getElementById('tourText');
    var prev = document.getElementById('tourPrev');
    var next = document.getElementById('tourNext');
    if (stepEl) stepEl.textContent = '演示 ' + (tourIdx + 1) + ' / ' + TOUR.length + ' · ' + step.title;
    if (textEl) textEl.textContent = step.text;
    if (prev) prev.disabled = tourIdx === 0;
    if (next) next.textContent = tourIdx === TOUR.length - 1 ? '完成' : '下一步';
    clearFocus();
    if (state.tab !== step.tab) showTab(step.tab);
    setTimeout(function () {
      var el = document.querySelector(step.sel);
      if (!el) return;
      el.classList.add('tour-focus');
      if (el.scrollIntoView) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      var inst = el.querySelector('.chart');
      if (inst && inst.id && state.charts[inst.id]) state.charts[inst.id].resize();
    }, 100);
  }

  function startTour() {
    tourIdx = 0;
    var panel = document.getElementById('tourPanel');
    if (panel) panel.hidden = false;
    renderTour();
  }

  function stopTour() {
    var panel = document.getElementById('tourPanel');
    if (panel) panel.hidden = true;
    clearFocus();
  }

  /* ============ CSV ============ */
  function splitCSV(text) {
    var first = text.split(/\r?\n/).find(function (l) { return l.trim(); }) || '';
    var counts = { ',': 0, ';': 0, '\t': 0 };
    for (var i = 0; i < first.length; i++) {
      if (counts[first[i]] != null) counts[first[i]] += 1;
    }
    var delim = ',';
    if (counts['\t'] > counts[delim] && counts['\t'] > counts[';']) delim = '\t';
    else if (counts[';'] > counts[',']) delim = ';';

    var rows = [], row = [], field = '', quoted = false;
    for (var j = 0; j < text.length; j++) {
      var ch = text[j];
      if (quoted) {
        if (ch === '"' && text[j + 1] === '"') { field += '"'; j++; }
        else if (ch === '"') quoted = false;
        else field += ch;
      } else if (ch === '"') quoted = true;
      else if (ch === delim) { row.push(field); field = ''; }
      else if (ch === '\n') { row.push(field.replace(/\r$/, '')); rows.push(row); row = []; field = ''; }
      else field += ch;
    }
    if (field.length || row.length) { row.push(field.replace(/\r$/, '')); rows.push(row); }
    rows = rows.filter(function (x) { return x.some(function (v) { return String(v).trim() !== ''; }); });
    if (!rows.length) return [];
    var headers = rows[0].map(function (h) { return h.replace(/^\uFEFF/, '').trim(); });
    return rows.slice(1).map(function (vals) {
      var o = {};
      headers.forEach(function (h, idx) { o[h] = vals[idx] == null ? '' : vals[idx]; });
      return o;
    });
  }

  function pick(obj, keys) {
    var names = Object.keys(obj);
    for (var i = 0; i < keys.length; i++) {
      for (var j = 0; j < names.length; j++) {
        if (names[j] === keys[i]) return obj[names[j]];
      }
    }
    for (var k = 0; k < keys.length; k++) {
      for (var n = 0; n < names.length; n++) {
        if (names[n].indexOf(keys[k]) >= 0) return obj[names[n]];
      }
    }
    return '';
  }

  function importCsv(text, fileName) {
    var target = ensureImportDs();
    var rows = splitCSV(String(text || '').replace(/^\uFEFF/, ''));
    var seen = {};
    target.txns.forEach(function (t) { seen[t.date + '|' + t.desc + '|' + t.amount + '|' + t.type] = 1; });
    var added = [], skipped = 0;
    rows.forEach(function (row) {
      var dateRaw = pick(row, ['日期', '交易日期', 'date']);
      var date = toISODate(dateRaw, ANCHOR_DATE);
      var amtRaw = pick(row, ['金额(元)', '金额', 'amount']);
      var amount = Number(String(amtRaw).replace(/[￥¥,，\s]/g, ''));
      var type = /收入|income/i.test(String(pick(row, ['类型', 'type']))) ? '收入' : '支出';
      var desc = String(pick(row, ['描述', '原始记录文本', 'description', '备注']) || '').trim();
      if (!/^20\d{2}-\d{2}-\d{2}$/.test(date) || !isFinite(amount) || amount <= 0 || !desc) { skipped++; return; }
      var key = date + '|' + desc + '|' + r2(amount) + '|' + type;
      if (seen[key]) { skipped++; return; }
      seen[key] = 1;
      var c = classify(desc, type);
      added.push(recordFrom({ date: date, type: type, amount: r2(amount), desc: desc, cat: c.cat, keyword: c.keyword, conf: c.conf }, 'csv'));
    });
    var status = document.getElementById('csvStatus');
    if (!added.length) {
      if (status) status.textContent = '没有新增记录，跳过 ' + skipped + ' 笔（重复或字段不完整）';
      if (!target.txns.length) {
        DS = DS.filter(function (d) { return d.id !== IMPORT_ID; });
        importDs = null;
      }
      toast('没有可导入的新记录');
      return;
    }
    Array.prototype.push.apply(target.txns, added);
    if (fileName) {
      var base = String(fileName).replace(/\.csv$/i, '').trim();
      if (base) target.name = base.length > 18 ? base.slice(0, 18) + '…' : base;
    }
    rebuildImport(target, skipped);
    if (status) status.textContent = '已导入 ' + added.length + ' 笔，跳过 ' + skipped + ' 笔；数据集「' + target.name + '」现有 ' + target.txns.length + ' 笔';
    writeStore();
    switchDs(IMPORT_ID, true);
    showTab('overview');
    toast('已导入 ' + added.length + ' 笔并切换到「' + target.name + '」（共 ' + target.txns.length + ' 笔），全站已按新数据重算');
  }

  function readText(file) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () {
        var text;
        try {
          text = new TextDecoder('utf-8', { fatal: true }).decode(fr.result);
        } catch (e) {
          text = new TextDecoder('gb18030').decode(fr.result);
        }
        resolve(text);
      };
      fr.onerror = function () { reject(fr.error); };
      fr.readAsArrayBuffer(file);
    });
  }

  /* ============ 事件 ============ */
  function bind() {
    var tabs = document.getElementById('tabs');
    if (tabs) {
      tabs.addEventListener('click', function (e) {
        var b = e.target.closest('button[data-tab]');
        if (b) showTab(b.getAttribute('data-tab'));
      });
      tabs.addEventListener('scroll', syncTabsHint);
    }

    var dsw = document.getElementById('dsSwitch');
    if (dsw) {
      dsw.addEventListener('click', function (e) {
        var b = e.target.closest('button[data-ds]');
        if (b) switchDs(b.getAttribute('data-ds'));
      });
    }

    var ms = document.getElementById('monthSelect');
    if (ms) {
      ms.addEventListener('change', function () {
        state.month = ms.value;
        renderAll();
      });
    }

    var tm = document.getElementById('trendMode');
    if (tm) {
      tm.addEventListener('click', function (e) {
        var b = e.target.closest('button[data-mode]');
        if (!b) return;
        state.trendMode = b.getAttribute('data-mode');
        Array.prototype.forEach.call(tm.querySelectorAll('button'), function (x) {
          x.classList.toggle('active', x === b);
        });
        renderTrend();
        var inst = state.charts.chartTrend;
        if (inst) setTimeout(function () { inst.resize(); }, 30);
      });
    }

    var kg = document.getElementById('kpiGrid');
    if (kg) {
      kg.addEventListener('click', function (e) {
        var b = e.target.closest('[data-goto]');
        if (b) showTab(b.getAttribute('data-goto'));
      });
    }

    var rl = document.getElementById('rankList');
    if (rl) {
      rl.addEventListener('click', function (e) {
        var row = e.target.closest('[data-cat]');
        if (row) drill(row.getAttribute('data-cat'));
      });
    }

    var si = document.getElementById('searchInput');
    if (si) si.addEventListener('input', function () { state.filters.q = si.value; renderDetail(); });
    ['filterType', 'filterMonth', 'filterCategory'].forEach(function (id) {
      var el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('change', function () {
        state.filters[{ filterType: 'type', filterMonth: 'month', filterCategory: 'cat' }[id]] = el.value;
        renderDetail();
      });
    });
    var rf = document.getElementById('resetFilter');
    if (rf) {
      rf.addEventListener('click', function () {
        state.filters = { q: '', type: '', month: '', cat: '' };
        syncFilterInputs();
        renderDetail();
      });
    }

    var ed = document.getElementById('exportDetail');
    if (ed) {
      ed.addEventListener('click', function () {
        var rows = detailRows();
        var lines = ['日期,类型,描述,分类,金额,命中词,账户,来源'];
        rows.forEach(function (t) {
          lines.push([t.date, t.type, '"' + String(t.desc).replace(/"/g, '""') + '"', t.cat, t.amount.toFixed(2),
            t.keyword, t.account, t.source === 'data' ? '账单' : '页面新增'].join(','));
        });
        var blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = '明细_' + getDs().id + '_' + (state.month || '全部月份') + '.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
        toast('已导出 ' + rows.length + ' 笔明细');
      });
    }

    var sa = document.getElementById('singleAdd');
    var sin = document.getElementById('singleInput');
    function doSingle() {
      var text = (sin && sin.value || '').trim();
      var box = document.getElementById('singleResult');
      if (!text) { toast('请输入一句话，例如：昨天午饭 25 元'); return; }
      var amount = parseAmount(text);
      if (!isFinite(amount) || amount <= 0) {
        if (box) { box.className = 'parse-result err'; box.textContent = '没有识别到有效金额，请带上“元 / 块”等金额，例如：昨天午饭 25 元。'; }
        return;
      }
      var type = inferType(text);
      var date = toISODate(text, ANCHOR_DATE);
      var c = classify(text, type);
      var rec = recordFrom({ date: date, type: type, amount: amount, desc: cleanDesc(text), cat: c.cat, keyword: c.keyword, conf: c.conf }, 'single');
      addRecords([rec], '已记一笔');
      if (box) {
        var st = ruleStrength(text, type);
        box.className = 'parse-result ok';
        box.innerHTML = '已写入：<b>' + esc(rec.desc) + '</b> · ' + esc(rec.cat) + ' · ' + esc(rec.type) +
          '<div class="rowline"><span>日期 <b>' + esc(date) + '</b></span><span>金额 <b>' + fmt(rec.amount) + '</b> 元</span>' +
          '<span>命中词 <b>' + esc(c.keyword) + '</b></span><span>规则强度 <b>' + esc(st.level) + '</b></span></div>';
      }
      if (sin) sin.value = '';
    }
    if (sa) sa.addEventListener('click', doSingle);
    if (sin) sin.addEventListener('keydown', function (e) { if (e.key === 'Enter') doSingle(); });

    var bp = document.getElementById('batchParse');
    if (bp) {
      bp.addEventListener('click', function () {
        var text = document.getElementById('batchInput').value;
        var res = parseBatch(text);
        state.batch = res;
        var box = document.getElementById('batchPreview');
        if (!box) return;
        if (!res.items.length) {
          box.innerHTML = '<div class="parse-result err">未解析出记录' + (res.errors.length ? '：' + esc(res.errors[0]) : '') + '</div>';
          return;
        }
        box.innerHTML = '<table class="tbl"><thead><tr><th>日期</th><th>描述</th><th>类型</th><th class="num">金额</th><th>分类</th><th>命中词</th></tr></thead><tbody>' +
          res.items.map(function (it) {
            return '<tr><td>' + esc(it.date) + '</td><td class="wrap">' + esc(it.desc) + '</td><td>' + esc(it.type) +
              '</td><td class="num">' + fmt(it.amount) + '</td><td>' + esc(it.cat) + '</td><td>' + esc(it.keyword) + '</td></tr>';
          }).join('') + '</tbody></table>' +
          (res.errors.length ? '<div class="parse-result err" style="margin-top:8px">' + res.errors.map(esc).join('<br>') + '</div>' : '') +
          '<div class="preview-actions"><button class="ghost" type="button" id="batchCancel">取消</button>' +
          '<button class="primary" type="button" id="batchConfirm">确认写入 ' + res.items.length + ' 笔</button></div>';
        var cancel = box.querySelector('#batchCancel');
        if (cancel) cancel.addEventListener('click', function () { box.innerHTML = ''; state.batch = null; });
        var ok = box.querySelector('#batchConfirm');
        if (ok) ok.addEventListener('click', function () {
          if (!state.batch) return;
          addRecords(state.batch.items.map(function (it) { return recordFrom(it, 'batch'); }), '批量录入');
          box.innerHTML = '';
          state.batch = null;
          document.getElementById('batchInput').value = '';
        });
      });
    }
    var bc = document.getElementById('batchClear');
    if (bc) bc.addEventListener('click', function () {
      document.getElementById('batchInput').value = '';
      document.getElementById('batchPreview').innerHTML = '';
      state.batch = null;
    });

    var cf = document.getElementById('csvFile');
    if (cf) {
      cf.addEventListener('change', function () {
        var f = cf.files && cf.files[0];
        if (!f) return;
        var status = document.getElementById('csvStatus');
        if (status) status.textContent = '正在读取 ' + f.name + ' …';
        readText(f).then(function (text) { importCsv(text, f.name); }).catch(function () {
          if (status) status.textContent = '读取失败，请确认文件为 CSV 文本';
        });
      });
    }
    var dc = document.getElementById('demoCsvBtn');
    if (dc) dc.addEventListener('click', function () {
      if (!DATA.demoCsv) { toast('示例 CSV 不可用'); return; }
      importCsv(DATA.demoCsv, '示例账单.csv');
    });

    var ci = document.getElementById('clearImport');
    if (ci) ci.addEventListener('click', function () {
      if (!importDs) { toast('当前没有导入的数据集'); return; }
      if (!window.confirm('清空导入数据集「' + importDs.name + '」？D1–D3 不受影响。')) return;
      var oldName = importDs.name;
      DS = DS.filter(function (d) { return d.id !== IMPORT_ID; });
      importDs = null;
      delete state.manual[IMPORT_ID];
      delete state.overrides[IMPORT_ID];
      delete state.budgetOverride[IMPORT_ID];
      if (state.ds === IMPORT_ID) state.ds = 'D1';
      writeStore();
      var status = document.getElementById('csvStatus');
      if (status) status.textContent = '未选择文件';
      var csvInput = document.getElementById('csvFile');
      if (csvInput) csvInput.value = '';
      switchDs(state.ds, true);
      toast('已清空导入数据集「' + oldName + '」，已切回 ' + getDs().id);
    });

    var ml = document.getElementById('manualList');
    if (ml) {
      ml.addEventListener('click', function (e) {
        var item = e.target.closest('[data-del]');
        if (!item) return;
        var id = item.getAttribute('data-del');
        var ds = getDs();
        state.manual[ds.id] = state.manual[ds.id].filter(function (t) { return t.id !== id; });
        markOutliers(ds);
        writeStore();
        renderAll();
        toast('已删除该笔记录');
      });
    }

    /* 复核：采用规则 / 采用模型 / 改其他分类 */
    var rbox = document.getElementById('reviewList');
    if (rbox) {
      rbox.addEventListener('click', function (e) {
        var item = e.target.closest('[data-review]');
        var btn = e.target.closest('[data-act]');
        if (!item || !btn) return;
        var t = findTxn(item.getAttribute('data-review'));
        if (!t) return;
        applyReview(t.id, btn.getAttribute('data-act') === 'model' ? t.modelCat : t.baseCat);
      });
      rbox.addEventListener('change', function (e) {
        var sel = e.target.closest('[data-review-select]');
        var item = e.target.closest('[data-review]');
        if (!sel || !item || !sel.value) return;
        applyReview(item.getAttribute('data-review'), sel.value);
      });
    }

    var aar = document.getElementById('acceptAllRule');
    if (aar) {
      aar.addEventListener('click', function () {
        var ds = getDs();
        var st = reviewStats(ds);
        if (!st.queue.length) { toast('没有待复核的分歧交易'); return; }
        st.queue.forEach(function (t) { state.overrides[ds.id][t.id] = t.baseCat; });
        ds.txns.forEach(function (t) {
          var v = state.overrides[ds.id][t.id];
          if (v) { t.cat = v; t.corrected = v !== t.baseCat; }
        });
        writeStore();
        renderAll();
        toast('已批量采用规则分类：' + st.queue.length + ' 笔');
      });
    }

    var cm = document.getElementById('clearManual');
    if (cm) {
      cm.addEventListener('click', function () {
        var ds = getDs();
        var n = (state.manual[ds.id] || []).length;
        if (!n) { toast('当前数据集没有手工录入记录'); return; }
        if (!window.confirm('清空 ' + n + ' 笔手工录入？原始账单不受影响。')) return;
        state.manual[ds.id] = [];
        markOutliers(ds);
        writeStore();
        renderAll();
        toast('已清空手工录入 ' + n + ' 笔');
      });
    }

    var rsc = document.getElementById('runSelfCheck');
    if (rsc) {
      rsc.addEventListener('click', function () {
        runSelfCheck();
        toast('自检完成，结果已更新');
      });
    }

    var rlocal = document.getElementById('resetLocal');
    if (rlocal) {
      rlocal.addEventListener('click', function () {
        if (!window.confirm('将清空本页新增记录、人工复核与预算调整，恢复到初始账单。确定吗？')) return;
        DS.forEach(function (d) {
          state.manual[d.id] = [];
          state.overrides[d.id] = {};
          state.budgetOverride[d.id] = {};
          d.txns.forEach(function (t) { t.cat = t.baseCat; t.corrected = false; });
        });
        writeStore();
        renderAll();
        toast('已清空本地改动');
      });
    }

    /* 预算：行内编辑 + 恢复默认 */
    var bl = document.getElementById('budgetList');
    if (bl) {
      bl.addEventListener('change', function (e) {
        var inp = e.target.closest('[data-bcat]');
        if (!inp) return;
        var cat = inp.getAttribute('data-bcat');
        var ds = getDs();
        var def = num((ds.budget[cat] || {}).monthly);
        var v = Number(inp.value);
        if (!isFinite(v) || v <= 0 || Math.abs(v - def) < 0.005) delete state.budgetOverride[ds.id][cat];
        else state.budgetOverride[ds.id][cat] = r2(v);
        writeStore();
        renderAll();
        toast('已调整 ' + cat + ' 月预算为 ' + fmt(state.budgetOverride[ds.id][cat] != null ? state.budgetOverride[ds.id][cat] : def) + ' 元');
      });
    }
    var rb = document.getElementById('resetBudget');
    if (rb) {
      rb.addEventListener('click', function () {
        state.budgetOverride[getDs().id] = {};
        writeStore();
        renderAll();
        toast('已恢复默认预算');
      });
    }

    var pb = document.getElementById('printBtn');
    if (pb) pb.addEventListener('click', function () { window.print(); });

    /* 3 分钟演示剧本 */
    var dt = document.getElementById('demoTour');
    if (dt) {
      dt.addEventListener('click', function () {
        if (document.getElementById('tourPanel') && !document.getElementById('tourPanel').hidden) stopTour();
        else startTour();
      });
    }
    var tp = document.getElementById('tourPrev');
    if (tp) tp.addEventListener('click', function () {
      if (tourIdx > 0) { tourIdx -= 1; renderTour(); }
    });
    var tn = document.getElementById('tourNext');
    if (tn) tn.addEventListener('click', function () {
      if (tourIdx >= TOUR.length - 1) { stopTour(); toast('演示结束，可以自由操作'); }
      else { tourIdx += 1; renderTour(); }
    });
    var te = document.getElementById('tourExit');
    if (te) te.addEventListener('click', stopTour);
    document.addEventListener('keydown', function (e) {
      var panel = document.getElementById('tourPanel');
      if (e.key === 'Escape' && panel && !panel.hidden) stopTour();
    });

    var rt = null;
    window.addEventListener('resize', function () {
      clearTimeout(rt);
      rt = setTimeout(function () {
        Object.keys(state.charts).forEach(function (k) {
          var el = document.getElementById(k);
          if (el && el.clientWidth > 0) state.charts[k].resize();
        });
      }, 160);
    });
  }

  /* ============ 真实统计：网络请求 & 页签横滑提示 ============ */
  function watchNetwork() {
    var el = document.getElementById('netCount');
    var n = 0;
    function bump(url) {
      var u = String(url || '');
      if (!/^https?:/i.test(u)) return; /* 本地 data.js / echarts.min.js 不算网络请求 */
      try {
        if (new URL(u, location.href).origin === location.origin) return; /* 同源静态资源不算 */
      } catch (e) { /* ignore */ }
      n += 1;
      if (el) el.textContent = n;
    }
    try {
      if (window.fetch) {
        var of = window.fetch;
        window.fetch = function (input) {
          bump(typeof input === 'string' ? input : (input && input.url));
          return of.apply(this, arguments);
        };
      }
    } catch (e) { /* ignore */ }
    try {
      var oo = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = function (method, url) {
        bump(url);
        return oo.apply(this, arguments);
      };
    } catch (e) { /* ignore */ }
    try {
      if (window.PerformanceObserver) {
        new PerformanceObserver(function (list) {
          list.getEntries().forEach(function (e) { bump(e.name); });
        }).observe({ type: 'resource', buffered: true });
      }
    } catch (e) { /* ignore */ }
  }

  function syncTabsHint() {
    var tabs = document.getElementById('tabs');
    if (!tabs) return;
    tabs.classList.toggle('more-right', tabs.scrollWidth - tabs.clientWidth - tabs.scrollLeft > 6);
    tabs.classList.toggle('more-left', tabs.scrollLeft > 6);
  }

  /* ============ 启动 ============ */
  bind();
  watchNetwork();
  syncTabsHint();
  window.addEventListener('resize', syncTabsHint);
  showTab('overview');
})();
