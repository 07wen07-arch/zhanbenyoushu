# -*- coding: utf-8 -*-
"""A 线：清洗、去重、对账、预算与异常标记（纯标准库）。

运行：python pipeline/build_clean.py
输出：out/clean.json
"""
import csv
import glob
import json
import re
import statistics
from collections import defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
OUT = ROOT / 'out'
CATEGORIES = ['餐饮', '居住', '交通', '通讯', '购物', '衣着', '娱乐', '学习', '医疗', '其他']


def r2(x):
    return round(float(x) + 1e-9, 2)


def read_csv(path):
    with open(path, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def iso_date(value):
    m = re.match(r'(20\d{2})[年/\-](\d{1,2})[月/\-](\d{1,2})', str(value or '').strip())
    if not m:
        raise ValueError('无法识别的日期: %r' % value)
    return '%s-%02d-%02d' % (m.group(1), int(m.group(2)), int(m.group(3)))


def load_budget(path):
    out = {}
    for row in read_csv(path):
        cat = (row.get('一级分类') or '').strip()
        if not cat:
            continue
        out[cat] = {
            'monthly': r2(float(row.get('月预算(元)') or 0)),
            'warn': float(row.get('预警线(%)') or 100),
            'note': (row.get('说明') or '').strip(),
        }
    return out


def mark_outliers(txns):
    by_cat = defaultdict(list)
    for t in txns:
        if t['type'] == '支出':
            by_cat[t['category_truth']].append(t['amount'])
    for t in txns:
        if t['type'] != '支出':
            t['is_outlier'] = False
            continue
        vals = by_cat[t['category_truth']]
        med = statistics.median(vals) if vals else t['amount']
        hit = t['amount'] >= max(500.0, med * 2.5)
        if '疑似大额异常' in t.get('note', ''):
            hit = True
        t['is_outlier'] = bool(hit)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    datasets = []
    for ds_id in ['D1', 'D2', 'D3']:
        raw_paths = glob.glob(str(DATA / '01_原始数据' / (ds_id + '_*') / '*原始导入*.csv'))
        budget_paths = glob.glob(str(DATA / '01_原始数据' / (ds_id + '_*') / '*预算*.csv'))
        if not raw_paths or not budget_paths:
            raise SystemExit('找不到 %s 的原始数据或预算文件' % ds_id)
        raw_path, budget_path = raw_paths[0], budget_paths[0]
        rows = read_csv(raw_path)
        seen, txns = set(), []
        dup_rows = 0
        raw_expense = raw_income = 0.0
        for idx, row in enumerate(rows, 1):
            txn_id = (row.get('交易ID') or '').strip() or '%s-%04d' % (ds_id, idx)
            amount = r2(float(str(row.get('金额(元)') or 0).replace(',', '')))
            typ = (row.get('类型') or '支出').strip()
            if typ == '支出':
                raw_expense += amount
            elif typ == '收入':
                raw_income += amount
            if txn_id in seen:
                dup_rows += 1
                continue
            seen.add(txn_id)
            d = iso_date(row.get('日期'))
            txns.append({
                'txn_id': txn_id, 'date': d, 'month': d[:7], 'type': typ,
                'amount': amount, 'desc': (row.get('描述') or '').strip(),
                'category_truth': (row.get('一级分类') or '').strip(),
                'subcategory': (row.get('二级分类') or '').strip(),
                'account': (row.get('账户') or '').strip(),
                'pay': (row.get('支付方式') or '').strip(),
                'raw_text': (row.get('原始记录文本') or '').strip(),
                'note': (row.get('备注') or '').strip(),
            })
        mark_outliers(txns)
        months = sorted({t['month'] for t in txns})
        monthly_map = defaultdict(float)
        detail_map = defaultdict(float)
        month_inc = defaultdict(float)
        for t in txns:
            if t['type'] == '支出':
                monthly_map[(t['month'], '支出', t['category_truth'])] += t['amount']
                detail_map[t['month']] += t['amount']
            elif t['type'] == '收入':
                monthly_map[(t['month'], '收入', t['category_truth'])] += t['amount']
                month_inc[t['month']] += t['amount']
        monthly = [
            {'month': m, 'type': typ, 'category': cat, 'amount': r2(amt)}
            for (m, typ, cat), amt in sorted(monthly_map.items())
        ]
        recon = []
        for m in months:
            raw_amt = r2(detail_map[m])
            clean_amt = r2(sum(x['amount'] for x in monthly if x['month'] == m and x['type'] == '支出'))
            recon.append({'month': m, 'raw': raw_amt, 'clean': clean_amt, 'diff': r2(raw_amt - clean_amt)})
        datasets.append({
            'id': ds_id,
            'name': {'D1': '个人', 'D2': '家庭', 'D3': '多账户'}[ds_id],
            'months': months,
            'budget': load_budget(budget_path),
            'totals': {
                'raw_rows': len(rows), 'dup_removed': dup_rows, 'clean_rows': len(txns),
                'expense': r2(sum(detail_map.values())), 'income': r2(sum(month_inc.values())),
                'raw_expense': r2(raw_expense), 'raw_income': r2(raw_income),
                'dup_amount': r2(raw_expense - sum(detail_map.values())),
            },
            'source': raw_path.split('\\')[-1],
            'txns': txns, 'monthly': monthly, 'recon': recon,
        })

    payload = {'generated_at': datetime.now().strftime('%Y-%m-%dT%H:%M:%S'),
               'categories': CATEGORIES, 'datasets': datasets}
    (OUT / 'clean.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    print('已写出 out/clean.json')
    print('%-4s %6s %6s %6s %12s %12s %8s' % ('组', '原始', '重复', '清洗', '支出', '收入', '异常'))
    for d in datasets:
        print('%-4s %6d %6d %6d %12.2f %12.2f %8d' % (
            d['id'], d['totals']['raw_rows'], d['totals']['dup_removed'], d['totals']['clean_rows'],
            d['totals']['expense'], d['totals']['income'],
            sum(1 for t in d['txns'] if t['is_outlier'])))
        for r in d['recon']:
            assert abs(r['diff']) < 0.005
    print('自检：明细与月度汇总差额均为 0.00')


if __name__ == '__main__':
    main()
