# -*- coding: utf-8 -*-
"""B 线：自然语言批量记账解析 + 143 条原始记录自测。

输入 out/clean.json、data/01_原始数据/D3_*/D3_批量自然语言录入.txt
输出 out/nl_parse.json
运行：python pipeline/nl_parse.py
"""
import json
import re
from collections import Counter
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out'
ANCHOR = date(2025, 12, 1)

# 规则表未覆盖、但批量文本里出现的常用词根，作为解析器补充
EXTRA_RULES = [
    ('交通', ['哈啰', '青桔', '月卡', '共享']),
    ('餐饮', ['海底捞', '外卖', '奶茶', '咖啡', '午饭', '早餐', '晚餐', '便利店']),
    ('购物', ['网购', '淘宝', '京东', '拼多多', '超市']),
    ('娱乐', ['电影', '会员', '游戏']),
    ('学习', ['买书', '课程']),
    ('居住', ['电费', '水费', '燃气', '房租']),
    ('通讯', ['话费', '流量']),
    ('其他', ['红包', '礼金', '人情']),
]
INCOME_WORDS = ['收到', '到账', '入账', '工资', '尾款', '稿费', '收益', '兼职', '退款', '赚', '提现']
SPEND_WORDS = ['给', '买', '交', '充', '花', '包', '打车', '吃', '付']


def load_rules():
    import csv
    path = ROOT / 'data' / '04_数据字典与说明' / '分类规则关键词表.csv'
    expense, income = [], []
    with open(path, encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            raw = (row.get('关键词列表(任一命中即归类)') or '').strip()
            cat = (row.get('目标分类') or '').strip()
            if not raw or not cat or '无命中' in raw:
                continue
            kws = [k.strip().lower() for k in raw.split('|') if k.strip()]
            (income if (row.get('顺序号') or '').startswith('A') else expense).append((cat, kws))
    return expense, income


EXPENSE_RULES, INCOME_RULES = load_rules()


def classify(text, typ='支出'):
    low = (text or '').lower()
    rules = (INCOME_RULES if typ == '收入' else EXPENSE_RULES) + (EXTRA_RULES if typ == '支出' else [])
    for cat, kws in rules:
        for kw in kws:
            if kw in low:
                return cat, kw
    return ('工资收入' if typ == '收入' else '其他'), '兜底'


def strip_dates(text):
    s = text
    s = re.sub(r'20\d{2}\s*年?\s*\d{1,2}\s*月\s*\d{1,2}\s*[日号]?', ' ', s)
    s = re.sub(r'\d{1,2}\s*月\s*\d{1,2}\s*[日号]?', ' ', s)
    s = re.sub(r'(今天|昨天|前天|大前天|上周[一二三四五六日天]|本周[一二三四五六日天])', ' ', s)
    s = re.sub(r'\d{1,2}\s*[日号]', ' ', s)
    return s


def parse_date(text, ctx=None):
    s = text or ''
    m = re.search(r'(20\d{2})\s*年?\s*(\d{1,2})\s*月\s*(\d{1,2})\s*[日号]?', s)
    if m:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    m = re.search(r'(\d{1,2})\s*月\s*(\d{1,2})\s*[日号]?', s)
    if m:
        base = ctx or ANCHOR
        return date(base.year, int(m.group(1)), int(m.group(2)))
    if '大前天' in s:
        return ANCHOR - timedelta(days=3)
    if '前天' in s:
        return ANCHOR - timedelta(days=2)
    if '昨天' in s:
        return ANCHOR - timedelta(days=1)
    if '今天' in s:
        return ANCHOR
    m = re.search(r'上周([一二三四五六日天])', s)
    if m:
        target = '一二三四五六日'.index(m.group(1)) if m.group(1) != '天' else 6
        delta = (ANCHOR.weekday() - target) % 7
        delta = 7 if delta == 0 else delta
        return ANCHOR - timedelta(days=delta)
    m = re.search(r'(\d{1,2})\s*[日号]', s)
    if m:
        base = ctx or ANCHOR
        return date(base.year, base.month, int(m.group(1)))
    return ctx or ANCHOR


def parse_amount(text):
    s = strip_dates(text)
    with_unit = re.findall(r'(\d+(?:\.\d+)?)\s*(?:元|块钱|块|rmb)', s, re.I)
    if with_unit:
        return float(with_unit[0])
    nums = re.findall(r'\d+(?:\.\d+)?', s)
    return float(nums[-1]) if nums else None


def infer_type(text):
    income = any(w in text for w in INCOME_WORDS)
    spend = any(w in text for w in SPEND_WORDS)
    return '收入' if income and not spend else '支出'


def clean_desc(text):
    s = strip_dates(text)
    s = re.sub(r'\d+(?:\.\d+)?\s*(?:元|块钱|块|rmb)', ' ', s, flags=re.I)
    s = re.sub(r'\d+(?:\.\d+)?', ' ', s)
    s = re.sub(r'[，。,.、:：;；]+', ' ', s)
    s = re.sub(r'\s+', ' ', s).strip()
    return s or (text or '').strip()


def parse_one(segment, ctx=None):
    amount = parse_amount(segment)
    if amount is None or amount <= 0:
        return None
    d = parse_date(segment, ctx)
    typ = infer_type(segment)
    pred, kw = classify(segment, typ)
    return {
        'date': d.isoformat(),
        'amount': round(amount, 2),
        'type': typ,
        'desc': clean_desc(segment),
        'raw': segment.strip(),
        'pred': pred,
        'rule_hit': kw,
        'confidence': 0.95 if kw != '兜底' else 0.55,
    }


def parse_batches(path):
    batches = []
    for i, line in enumerate(open(path, encoding='utf-8-sig').read().splitlines(), 1):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        segments = [s.strip() for s in re.split(r'[；;]', line) if s.strip()]
        ctx = None
        items = []
        for seg in segments:
            d = parse_date(seg, ctx)
            if ctx is None:
                ctx = d
            item = parse_one(seg, ctx)
            if item:
                item['batch_no'] = len(batches) + 1
                items.append(item)
            ctx = d
        if items:
            batches.append({'batch_no': len(batches) + 1, 'line': line, 'items': items})
    return batches


def main():
    clean = json.loads((OUT / 'clean.json').read_text(encoding='utf-8'))
    d3 = next(d for d in clean['datasets'] if d['id'] == 'D3')
    nl_paths = list((ROOT / 'data' / '01_原始数据').glob('D3_*/*批量自然语言录入*.txt'))
    if not nl_paths:
        raise SystemExit('找不到 D3 批量自然语言录入文件')
    batches = parse_batches(nl_paths[0])
    batch_items = sum(len(b['items']) for b in batches)

    rows = [t for t in d3['txns'] if t.get('raw_text')]
    date_ok = amount_ok = cat_ok = 0
    errors = []
    for t in rows:
        item = parse_one(t['raw_text'])
        if not item:
            errors.append(t['raw_text'])
            continue
        date_ok += int(item['date'] == t['date'])
        amount_ok += int(abs(item['amount'] - t['amount']) < 0.005)
        cat_ok += int(item['pred'] == t['category_truth'])
        if item['pred'] != t['category_truth'] or item['date'] != t['date'] or abs(item['amount'] - t['amount']) >= 0.005:
            errors.append({'raw': t['raw_text'], 'truth': [t['date'], t['amount'], t['category_truth']],
                           'got': [item['date'], item['amount'], item['pred']]})
    n = len(rows)
    payload = {
        'anchor_date': ANCHOR.isoformat(),
        'batches': batches,
        'batch_count': len(batches),
        'batch_items': batch_items,
        'selfcheck': {
            'n': n,
            'date_acc': round(date_ok / n, 4) if n else 0,
            'amount_acc': round(amount_ok / n, 4) if n else 0,
            'category_acc': round(cat_ok / n, 4) if n else 0,
        },
        'errors': errors[:15],
        'note': '批量文件表头写 23 笔，实际可解析 %d 笔；以实际内容为准。' % batch_items,
    }
    (OUT / 'nl_parse.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    print('批量批次 %d，解析 %d 笔' % (len(batches), batch_items))
    print('143 条自测：日期 %.2f%% | 金额 %.2f%% | 分类 %.2f%%' % (
        payload['selfcheck']['date_acc'] * 100,
        payload['selfcheck']['amount_acc'] * 100,
        payload['selfcheck']['category_acc'] * 100))
    if errors:
        print('异常样例（最多 5 条）:')
        for e in errors[:5]:
            print(' ', e)


if __name__ == '__main__':
    main()
