# -*- coding: utf-8 -*-
"""D 线：预算预警、异常解释、八大类对照与自动小结。

输入 out/clean.json、out/classified.json
输出 out/insight.json
运行：python pipeline/build_insight.py
"""
import csv
import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out'
DATA = ROOT / 'data'


def r2(x):
    return round(float(x) + 1e-9, 2)


def read_csv(path):
    with open(path, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def load_mapping():
    path = DATA / '04_数据字典与说明' / '分类映射表_工具分类_vs_统计局八大类.csv'
    out = {}
    for row in read_csv(path):
        if (row.get('收支方向') or '').strip() == '支出':
            out[(row.get('工具一级分类') or '').strip()] = (row.get('对应国家统计局八大类(支出)/四项来源(收入)') or '').strip()
    return out


def load_benchmark():
    path = DATA / '01_原始数据' / '00_权威统计基准_真实摘录' / '国家统计局_居民消费八大类结构_整理版.csv'
    rows = read_csv(path)
    period = '2026年前三季度'
    result = {}
    source = ''
    for row in rows:
        if (row.get('期间') or '').strip() != period:
            continue
        scope = (row.get('口径') or '').strip()
        cat = (row.get('消费大类') or '').strip()
        if cat == '人均消费支出合计' or not scope:
            continue
        try:
            share = float(row.get('占总消费支出比重(%)') or 0) / 100.0
        except ValueError:
            continue
        result.setdefault(cat, {})[scope] = share
        source = row.get('数据来源') or source
    return period, result, source


MAPPING = load_mapping()
PERIOD, BENCH, SOURCE = load_benchmark()


def month_totals(txns, month):
    rows = [t for t in txns if t['month'] == month]
    expense = r2(sum(t['amount'] for t in rows if t['type'] == '支出'))
    income = r2(sum(t['amount'] for t in rows if t['type'] == '收入'))
    by_cat = defaultdict(float)
    for t in rows:
        if t['type'] == '支出':
            by_cat[t['category_truth']] += t['amount']
    return rows, expense, income, {k: r2(v) for k, v in by_cat.items()}


def month_summary(ds, month, prev_expense, prev_map):
    rows, expense, income, by_cat = month_totals(ds['txns'], month)
    top_cat = max(by_cat, key=by_cat.get) if by_cat else None
    top_amt = by_cat[top_cat] if top_cat else 0
    parts = []
    if top_cat:
        parts.append('%s支出 %s 元，最大类别是%s，共 %s 元，占当月支出的 %.1f%%。' % (
            month, f'{expense:,.2f}', top_cat, f'{top_amt:,.2f}',
            (top_amt / expense * 100) if expense else 0))
    diffs = []
    for cat, amt in by_cat.items():
        diffs.append((abs(amt - prev_map.get(cat, 0)), cat, amt - prev_map.get(cat, 0)))
    diffs.sort(reverse=True)
    if prev_expense is not None and diffs:
        _, cat, delta = diffs[0]
        direction = '增加' if delta >= 0 else '减少'
        parts.append('与上月相比，%s变化最大，金额%s %s 元。' % (cat, direction, f'{abs(delta):,.2f}'))
    elif prev_expense is None:
        parts.append('这是账本中的第一个月，暂无上月可比数据。')

    budget = ds.get('budget', {})
    over = [(c, by_cat.get(c, 0), budget[c]['monthly']) for c in budget
            if by_cat.get(c, 0) > budget[c]['monthly']]
    warn = [(c, by_cat.get(c, 0), budget[c]['monthly'], budget[c].get('warn', 100)) for c in budget
            if budget[c]['monthly'] and budget[c].get('warn', 100) <= by_cat.get(c, 0) / budget[c]['monthly'] * 100 <= 100]
    anomalies = [t for t in rows if t.get('is_outlier')]
    if expense > income:
        parts.append('本月支出高于收入 %s 元，处于收不抵支状态。' % f'{expense - income:,.2f}')
    elif over:
        parts.append('%s 超出月预算，合计超出 %s 元。' % (
            '、'.join(c for c, _, _ in over), f'{sum(a - b for _, a, b in over):,.2f}'))
    elif warn:
        parts.append('%s 已接近预算预警线，建议核对明细。' % '、'.join(c for c, _, _, _ in warn))
    elif anomalies:
        parts.append('检测到 %d 笔相对同类偏高的支出，建议人工确认。' % len(anomalies))
    else:
        parts.append('本月结余 %s 元，未触发预算预警。' % f'{income - expense:,.2f}')
    parts.append('以上仅为账单数据的描述性统计，不代表因果结论。')
    return parts


def eight_category(by_cat, expense):
    agg = defaultdict(float)
    for cat, amt in by_cat.items():
        target = MAPPING.get(cat)
        if target:
            agg[target] += amt
    rows = []
    for cat in ['食品烟酒', '衣着', '居住', '生活用品及服务', '交通通信', '教育文化娱乐', '医疗保健', '其他用品及服务']:
        amt = r2(agg.get(cat, 0))
        b = BENCH.get(cat, {})
        rows.append({
            'cat': cat, 'mine': round(amt / expense, 4) if expense else 0,
            'mine_amount': amt,
            'national': round(b.get('全国', 0), 4),
            'urban': round(b.get('城镇', 0), 4),
            'rural': round(b.get('农村', 0), 4),
        })
    return rows


def main():
    clean = json.loads((OUT / 'clean.json').read_text(encoding='utf-8'))
    classified = json.loads((OUT / 'classified.json').read_text(encoding='utf-8'))
    insight = {
        'generated_at': datetime.now().strftime('%Y-%m-%dT%H:%M:%S'),
        'benchmark': {'period': PERIOD, 'source': SOURCE},
        'mapping': MAPPING,
        'datasets': {},
    }
    for ds in clean['datasets']:
        months = ds['months']
        latest = months[-1]
        rows, expense, income, by_cat = month_totals(ds['txns'], latest)
        prev = months[-2] if len(months) >= 2 else None
        prev_expense = prev_map = None
        if prev:
            _, prev_expense, _, prev_map = month_totals(ds['txns'], prev)

        budget_alerts = []
        for cat, cfg in ds.get('budget', {}).items():
            actual = r2(by_cat.get(cat, 0))
            monthly = cfg['monthly']
            pct = round(actual / monthly * 100, 1) if monthly else 0
            status = '超支' if actual > monthly else ('预警' if pct >= cfg.get('warn', 100) else '正常')
            budget_alerts.append({
                'cat': cat, 'budget': monthly, 'actual': actual,
                'over': r2(max(0, actual - monthly)), 'pct': pct, 'warn': cfg.get('warn', 100),
                'status': status,
            })
        budget_alerts.sort(key=lambda x: x['pct'], reverse=True)

        cat_values = defaultdict(list)
        for t in ds['txns']:
            if t['type'] == '支出':
                cat_values[t['category_truth']].append(t['amount'])
        anomalies = []
        for t in ds['txns']:
            if not t.get('is_outlier'):
                continue
            vals = cat_values[t['category_truth']]
            mean = sum(vals) / len(vals) if vals else t['amount']
            anomalies.append({
                'txn_id': t['txn_id'], 'date': t['date'], 'desc': t['desc'],
                'category': t['category_truth'], 'amount': t['amount'],
                'mean': r2(mean), 'ratio': round(t['amount'] / mean, 2) if mean else 1,
            })
        anomalies.sort(key=lambda x: x['amount'], reverse=True)

        monthly_summaries = {}
        for i, m in enumerate(months):
            pe = None
            pm = None
            if i > 0:
                _, pe, _, pm = month_totals(ds['txns'], months[i - 1])
            monthly_summaries[m] = month_summary(ds, m, pe, pm or {})

        top = sorted(by_cat.items(), key=lambda x: x[1], reverse=True)[:5]
        insight['datasets'][ds['id']] = {
            'latest_month': latest,
            'summary': monthly_summaries[latest],
            'monthly_summaries': monthly_summaries,
            'top_categories': [{'cat': c, 'amount': a, 'share': round(a / expense, 4) if expense else 0} for c, a in top],
            'eight_category': eight_category(by_cat, expense),
            'budget_alerts': budget_alerts,
            'anomalies': anomalies,
            'deficit': expense > income,
            'expense': expense,
            'income': income,
            'balance': r2(income - expense),
        }

    (OUT / 'insight.json').write_text(json.dumps(insight, ensure_ascii=False, indent=2), encoding='utf-8')
    print('基准期间:', PERIOD)
    for ds_id, d in insight['datasets'].items():
        print('%s 最新月 %s | 支出 %.2f | 结余 %.2f | 超支 %d | 异常 %d | 收不抵支 %s' % (
            ds_id, d['latest_month'], d['expense'], d['balance'],
            sum(1 for x in d['budget_alerts'] if x['status'] == '超支'),
            len(d['anomalies']), d['deficit']))
        print('  小结:', d['summary'][0])
    print('已写出 out/insight.json')


if __name__ == '__main__':
    main()
