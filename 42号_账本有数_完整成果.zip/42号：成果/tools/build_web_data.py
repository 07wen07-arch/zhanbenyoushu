# -*- coding: utf-8 -*-
"""C 线：把 out/*.json 合成 web/data.js，供双击 index.html 离线读取。

运行：python tools/build_web_data.py
"""
import csv
import datetime
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out'
WEB = ROOT / 'web'
RULES_PATH = ROOT / 'data' / '04_数据字典与说明' / '分类规则关键词表.csv'

FILES = [
    ('clean', 'clean.json', True),
    ('classified', 'classified.json', True),
    ('eval', 'eval.json', True),
    ('model', 'model.json', True),
    ('nl', 'nl_parse.json', False),
    ('insight', 'insight.json', False),
]

DEMO_CSV = """日期,描述,金额(元),类型,账户
2025-12-01,早餐-豆浆油条,8.5,支出,微信
2025-12-01,地铁通勤,6,支出,支付宝
2025-12-02,午餐-公司食堂,28,支出,微信
2025-12-02,兼职稿费,800,收入,银行卡
2025-12-03,超市-日用品,126.4,支出,支付宝
"""


def read_rules():
    """读取赛题规则表，导出给前端使用，避免 app.js 再手写一份。"""
    expense, income = [], []
    fallback = {'支出': '其他', '收入': '工资收入'}
    with open(RULES_PATH, encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            order = (row.get('顺序号') or '').strip()
            cat = (row.get('目标分类') or '').strip()
            raw = (row.get('关键词列表(任一命中即归类)') or '').strip()
            if not cat:
                continue
            bucket = income if order.startswith('A') else expense
            if '无命中' in raw or not raw:
                fallback['收入' if bucket is income else '支出'] = cat
                continue
            keywords = [k.strip().lower() for k in raw.split('|') if k.strip()]
            bucket.append([cat, keywords])
    return {'expense': expense, 'income': income, 'fallback': fallback}


def main():
    payload = {
        'meta': {
            'built_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'project': '题五 账本有数',
        },
        'demoCsv': DEMO_CSV,
        'rules': read_rules(),
    }
    for key, name, required in FILES:
        path = OUT / name
        if not path.exists():
            print(('[ERROR] ' if required else '[WARN] ') + '缺少 %s' % path)
            payload[key] = None
            continue
        payload[key] = json.loads(path.read_text(encoding='utf-8'))
        print('[ OK ] %-12s %7.1f KB' % (key, path.stat().st_size / 1024))

    WEB.mkdir(parents=True, exist_ok=True)
    target = WEB / 'data.js'
    with open(target, 'w', encoding='utf-8') as f:
        f.write('/* 自动生成，请勿手改；源：out/*.json */\n')
        f.write('window.T5DATA = ')
        json.dump(payload, f, ensure_ascii=False, separators=(',', ':'))
        f.write(';\n')
    print('已生成 %s（%.1f KB）' % (target, target.stat().st_size / 1024))


if __name__ == '__main__':
    main()
