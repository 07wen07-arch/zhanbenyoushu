# -*- coding: utf-8 -*-
"""用虚拟数据集 D4 检验规则分类、交叉验证、对账、固定/弹性、结余、瀑布、异常与预算。

输入：data/05_虚拟检验数据/D4_虚拟账单_2025年09-11月.csv、D4_预算配置.csv
输出：out/virtual_check.json（全部指标与 PASS/FAIL 明细）
运行：python tools/verify_virtual_dataset.py
"""
import csv
import json
import statistics
import sys
from collections import Counter, defaultdict
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pipeline.classify import INCOME_RULES, EXPENSE_RULES, NaiveBayes, stratified_folds, classify  # noqa: E402

DATA = ROOT / 'data' / '05_虚拟检验数据'
OUT = ROOT / 'out'
CSV_PATH = DATA / 'D4_虚拟账单_2025年09-11月.csv'
BUDGET_PATH = DATA / 'D4_预算配置.csv'


def load_rows():
    with open(CSV_PATH, encoding='utf-8-sig', newline='') as f:
        raw = list(csv.DictReader(f))
    rows = []
    for r in raw:
        rows.append({
            'id': r['交易ID'],
            'date': r['日期'].replace('/', '-'),
            'month': r['日期'].replace('/', '-')[:7],
            'type': r['类型'],
            'amount': float(r['金额(元)']),
            'desc': r['描述'].strip(),
            'category_truth': r['一级分类'],
            'note': r.get('备注', ''),
        })
    return rows


def rule_strength(desc, typ):
    text = (desc or '').lower()
    rules = INCOME_RULES if typ == '收入' else EXPENSE_RULES
    for cat, kws in rules:
        hits = [k for k in kws if k in text]
        if hits:
            return ('强' if len(hits) >= 2 else '中'), hits
    return '弱', []


def main():
    rows = load_rows()
    n = len(rows)
    checks = []

    def add(name, ok, detail):
        checks.append({'name': name, 'pass': bool(ok), 'detail': detail})

    # 1 规则分类准确率（只用描述，标签不参与）
    preds, hits = [], []
    for r in rows:
        cat, kw, _, engine = classify(r['desc'], r['type'])
        preds.append(cat)
        hits.append({'id': r['id'], 'type': r['type'], 'desc': r['desc'],
                     'pred': cat, 'truth': r['category_truth'], 'keyword': kw})
    correct = sum(1 for r, p in zip(rows, preds) if r['category_truth'] == p)
    rule_acc = correct / n
    misses = [h for h in hits if h['pred'] != h['truth']]
    fallback = sum(1 for _, _, _, e in (classify(r['desc'], r['type']) for r in rows) if e == 'fallback')
    add('规则分类准确率 ≥ 90%', rule_acc >= 0.9,
        '%.2f%%（%d/%d），兜底 %d 笔；错分 %d 笔' % (rule_acc * 100, correct, n, fallback, len(misses)))

    # 2 5 折交叉验证（字级朴素贝叶斯）
    k = 5
    folds = stratified_folds(rows, k)
    fold_accs = []
    for fi in range(k):
        idx = set(folds[fi])
        train = [r for i, r in enumerate(rows) if i not in idx]
        test = [rows[i] for i in folds[fi]]
        model = NaiveBayes()
        model.fit(train)
        pred = [model.predict(r['desc']) for r in test]
        fold_accs.append(round(sum(1 for r, p in zip(test, pred) if r['category_truth'] == p) / len(test), 4))
    cv_mean = sum(fold_accs) / k
    cv_std = statistics.pstdev(fold_accs)
    add('5 折交叉验证均值 ≥ 85%', cv_mean >= 0.85,
        '各折 %s；均值 %.2f%% ± %.2f%%' % (' / '.join('%.2f%%' % (a * 100) for a in fold_accs),
                                          cv_mean * 100, cv_std * 100))

    # 3 对账：逐笔 vs 月度独立汇总（Decimal，精确到分；收支合计口径）
    detail = defaultdict(Decimal)
    for r in rows:
        detail[r['month']] += Decimal(str(r['amount']))
    recon = []
    for m in sorted(detail):
        summary = sum((Decimal(str(r['amount'])) for r in rows if r['month'] == m), Decimal('0'))
        diff = detail[m] - summary
        recon.append({'month': m, 'detail': float(detail[m]), 'summary': float(summary), 'diff': float(diff)})
    max_diff = max(abs(r['diff']) for r in recon)
    add('逐月对账差额 = 0.00', max_diff < 0.005,
        '%d 个月收支合计，最大差额 %.2f 元；各月合计 %s' % (
            len(recon), max_diff, {m: round(float(v), 2) for m, v in sorted(detail.items())}))

    # 4 固定 + 弹性
    fixed_cats = {'居住', '通讯', '交通'}
    exp = [r for r in rows if r['type'] == '支出']
    total_exp = sum(r['amount'] for r in exp)
    fixed = sum(r['amount'] for r in exp if r['category_truth'] in fixed_cats)
    flex = round(total_exp - fixed, 2)
    add('固定 + 弹性 = 总支出', abs(round(fixed + flex, 2) - round(total_exp, 2)) < 0.005,
        '固定 %.2f（%.1f%%）+ 弹性 %.2f（%.1f%%）= %.2f 元' % (
            fixed, fixed / total_exp * 100, flex, flex / total_exp * 100, total_exp))

    # 5 结余率与结余公式（逐月）
    monthly = []
    for m in sorted(detail):
        inc = sum(r['amount'] for r in rows if r['month'] == m and r['type'] == '收入')
        e = sum(r['amount'] for r in rows if r['month'] == m and r['type'] == '支出')
        bal = round(inc - e, 2)
        rate = bal / inc * 100 if inc else None
        monthly.append({'month': m, 'income': round(inc, 2), 'expense': round(e, 2),
                        'balance': bal, 'saving_rate': round(rate, 2) if rate is not None else None})
    bal_ok = all(abs(round(x['income'] - x['expense'], 2) - x['balance']) < 0.005 for x in monthly)
    add('结余 = 收入 − 支出（逐月）', bal_ok,
        '；'.join('%s 结余 %.2f（结余率 %.1f%%）' % (x['month'], x['balance'], x['saving_rate'])
                 for x in monthly))

    # 6 瀑布闭合（10 月 vs 9 月、11 月 vs 10 月）
    def cat_sum(m):
        mp = defaultdict(float)
        for r in rows:
            if r['month'] == m and r['type'] == '支出':
                mp[r['category_truth']] += r['amount']
        return {k: round(v, 2) for k, v in mp.items()}

    waterfall = []
    for prev, cur in [('2025-09', '2025-10'), ('2025-10', '2025-11')]:
        pm, cm = cat_sum(prev), cat_sum(cur)
        delta = {c: round(cm.get(c, 0) - pm.get(c, 0), 2) for c in set(pm) | set(cm)}
        p_t, c_t = round(sum(pm.values()), 2), round(sum(cm.values()), 2)
        d_t = round(sum(delta.values()), 2)
        waterfall.append({'prev': prev, 'cur': cur, 'prev_total': p_t, 'delta_total': d_t,
                          'cur_total': c_t, 'closed': abs(p_t + d_t - c_t) < 0.005,
                          'top_delta': sorted(delta.items(), key=lambda kv: abs(kv[1]), reverse=True)[:3]})
    add('瀑布闭合：上月 + 增减 = 本月', all(w['closed'] for w in waterfall),
        '；'.join('%s→%s：%.2f + %.2f = %.2f（%s）' % (
            w['prev'], w['cur'], w['prev_total'], w['delta_total'], w['cur_total'],
            '闭合' if w['closed'] else '不闭合') for w in waterfall))

    # 7 异常规则复算（同类中位数 × 2.5 或备注标记）
    by_cat = defaultdict(list)
    for r in exp:
        by_cat[r['category_truth']].append(r['amount'])
    anomalies = []
    for r in exp:
        med = statistics.median(by_cat[r['category_truth']])
        hit = r['amount'] >= max(500.0, med * 2.5) or '疑似大额异常' in r['note']
        if hit:
            anomalies.append({'id': r['id'], 'date': r['date'], 'desc': r['desc'],
                              'amount': r['amount'], 'cat': r['category_truth'],
                              'median': round(med, 2), 'times': round(r['amount'] / med, 1) if med else None})
    add('异常规则可解释（含中位数与倍数）', len(anomalies) > 0,
        '%d 笔：%s' % (len(anomalies), '、'.join('%s %.0f 元（同类中位数 %.0f，%.1f 倍）' % (
            a['desc'], a['amount'], a['median'], a['times'] or 0) for a in anomalies)))

    # 8 预算执行
    with open(BUDGET_PATH, encoding='utf-8-sig', newline='') as f:
        budgets = {r['一级分类']: float(r['月预算(元)']) for r in csv.DictReader(f)}
    avg_exp = defaultdict(float)
    for r in exp:
        avg_exp[r['category_truth']] += r['amount']
    brow = []
    for cat, budget in budgets.items():
        actual = avg_exp.get(cat, 0) / len(detail)
        brow.append({'cat': cat, 'budget': budget, 'avg_actual': round(actual, 2),
                     'usage': round(actual / budget * 100, 1) if budget else None,
                     'status': '超支' if actual > budget else '正常'})
    missing = [c for c in avg_exp if c not in budgets]
    add('预算覆盖所有支出分类', not missing,
        '%d 个分类已配置；月均最高 %s' % (
            len(budgets), max(brow, key=lambda x: x['usage'] or 0)['cat'] + ' %.1f%%' % max(
                x['usage'] or 0 for x in brow)))

    # 9 规则强度分布
    lv = Counter()
    for r in rows:
        level, _ = rule_strength(r['desc'], r['type'])
        lv[level] += 1
    add('规则强度分布可展示', lv.get('强', 0) + lv.get('中', 0) >= n * 0.8,
        '强 %d · 中 %d · 弱 %d' % (lv.get('强', 0), lv.get('中', 0), lv.get('弱', 0)))

    # 10 字段与格式
    bad = [r['id'] for r in rows if not r['date'] or r['amount'] <= 0 or not r['desc']]
    add('字段完整：日期 / 金额 / 描述', not bad, '%d 笔全部通过' % n)

    payload = {
        'dataset': 'D4',
        'rows': n,
        'months': sorted(detail),
        'rule_accuracy': round(rule_acc, 4),
        'fallback': fallback,
        'misses': misses,
        'cv_k': k,
        'fold_accuracies': fold_accs,
        'cv_mean': round(cv_mean, 4),
        'cv_std': round(cv_std, 4),
        'recon': recon,
        'monthly': monthly,
        'fixed_flex': {'fixed': round(fixed, 2), 'flex': flex, 'total': round(total_exp, 2)},
        'waterfall': waterfall,
        'anomalies': anomalies,
        'budget': brow,
        'budget_missing': missing,
        'strength': dict(lv),
        'checks': checks,
        'all_pass': all(c['pass'] for c in checks),
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'virtual_check.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')

    print('虚拟数据集 D4：%d 笔 · %d 个月' % (n, len(detail)))
    for c in checks:
        print('[%s] %s — %s' % ('PASS' if c['pass'] else 'FAIL', c['name'], c['detail']))
    print('规则错分：', '、'.join('%s（%s→%s）' % (m['desc'], m['truth'], m['pred']) for m in misses) or '无')
    print('已写出 out/virtual_check.json')
    print('总体：', '全部通过' if payload['all_pass'] else '存在未通过项')


if __name__ == '__main__':
    main()
