# -*- coding: utf-8 -*-
"""依据官方账单的字段与消费模式，生成一份可导入/可复算的虚拟数据集 D4。

输出：
  data/05_虚拟检验数据/D4_虚拟账单_2025年09-11月.csv
  data/05_虚拟检验数据/D4_预算配置.csv
运行：python tools/gen_virtual_dataset.py
"""
import csv
import random
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'data' / '05_虚拟检验数据'
RNG = random.Random(42)
WEEK = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']
ANCHOR_MONTHS = [(2025, 9), (2025, 10), (2025, 11)]

rows = []
seq = 0


def add(d, typ, amount, desc, sub, cat, pay='微信支付', note='规则标注', account='微信零钱'):
    global seq
    seq += 1
    rows.append({
        '交易ID': 'D4-%04d' % seq,
        '日期': d.strftime('%Y/%m/%d'),
        '星期': WEEK[d.weekday()],
        '类型': typ,
        '金额(元)': round(amount, 2),
        '描述': desc,
        '二级分类': sub,
        '一级分类': cat,
        '账户': account,
        '支付方式': pay,
        '备注': note,
    })


def days_of(y, m):
    d = date(y, m, 1)
    while d.month == m:
        yield d
        d += timedelta(days=1)


# 每月固定 + 日常消费；金额围绕官方中位数做小幅扰动
for idx, (y, m) in enumerate(ANCHOR_MONTHS):
    days = list(days_of(y, m))
    add(days[0], '支出', 2400, '房租-城东公寓', '房租', '居住', '银行卡', account='招行储蓄卡')
    add(days[2], '支出', 59, '中国移动-话费套餐', '话费', '通讯', '支付宝', account='支付宝余额')
    add(days[4], '支出', [186.4, 203.7, 221.3][idx], '水电燃气费', '水电燃气', '居住', '支付宝', account='支付宝余额')
    add(days[9], '收入', 9800, '工资-某科技有限公司', '工资', '工资收入', '银行卡', account='招行储蓄卡')
    add(days[9], '收入', [86.5, 92.3, 120.8][idx], '理财收益-余额宝', '理财', '理财收益', '支付宝', account='支付宝余额')
    if m in (9, 11):
        add(days[14], '收入', [800, 1200][0 if m == 9 else 1], '兼职-线上助教', '兼职', '兼职收入', '支付宝', account='支付宝余额')
    if m == 10:
        add(days[11], '收入', 200, '红包-家人', '红包', '红包转账', '微信支付', account='微信零钱')

    for i, d in enumerate(days):
        if d.weekday() < 5:
            add(d, '支出', RNG.uniform(3, 6), '地铁-通勤', '地铁', '交通', '微信支付')
            add(d, '支出', RNG.uniform(3, 6), '地铁-通勤', '地铁', '交通', '微信支付')
            add(d, '支出', RNG.uniform(6, 11), ['便利蜂早餐', '豆浆油条', '包子铺-小笼包'][i % 3],
                '早餐', '餐饮', '微信支付')
            add(d, '支出', RNG.uniform(16, 32), ['公司食堂午餐', '外卖-黄焖鸡米饭', '社区面馆-牛肉面'][i % 3],
                '午餐', '餐饮', '微信支付')
            if i % 3 == 0:
                add(d, '支出', RNG.uniform(9.9, 19), ['瑞幸咖啡-生椰拿铁', '蜜雪冰城-柠檬水'][i % 2],
                    '咖啡茶饮', '餐饮', '微信支付')
            if i % 5 == 0:
                add(d, '支出', RNG.uniform(45, 130), ['社区菜市场-生鲜蔬菜', '永辉超市-粮油副食'][i % 2],
                    '食材', '餐饮', '微信支付')
        else:
            add(d, '支出', RNG.uniform(28, 46), ['外卖-麻辣烫', '社区面馆-牛肉面', '麦当劳套餐'][i % 3],
                '晚餐', '餐饮', '微信支付')
            if i % 2 == 0:
                add(d, '支出', RNG.uniform(80, 260), ['海底捞-周末聚餐', '萨莉亚-简餐'][i % 2],
                    '聚餐', '餐饮', '微信支付')
            add(d, '支出', RNG.uniform(45, 70), '万达影城-电影票', '电影', '娱乐', '微信支付')
        if i % 7 == 1:
            add(d, '支出', 1.5, '美团单车', '共享单车', '交通', '微信支付')
        if i % 9 == 3:
            add(d, '支出', 25, '腾讯视频-会员', '会员', '娱乐', '微信支付')
        if i % 11 == 4:
            add(d, '支出', RNG.uniform(30, 160), ['京东超市-纸巾日化', '屈臣氏-洗护用品'][i % 2],
                '日用品', '购物', '京东支付', account='招行储蓄卡')
        if i % 13 == 5:
            add(d, '支出', 35, '快剪-理发', '理发', '其他', '微信支付')

    add(days[16], '支出', RNG.uniform(45, 90), '京东图书-经济学原理', '图书', '学习', '京东支付')
    add(days[18], '支出', RNG.uniform(20, 60), '同仁堂-感冒药', '药品', '医疗', '微信支付')
    add(days[21], '支出', 12, '菜鸟驿站-寄件', '快递', '其他', '微信支付')
    if m == 9:
        add(days[7], '支出', 680, '社区医院-年度体检', '体检', '医疗', '银行卡', account='招行储蓄卡')
        add(days[19], '支出', 299, '优衣库-秋季卫衣', '服装', '衣着', '支付宝', account='支付宝余额')
    if m == 10:
        add(days[3], '支出', 3299, '京东-红米手机', '数码', '购物', '京东支付', account='招行储蓄卡')
        add(days[15], '支出', 600, '随礼-同事婚礼', '人情', '其他', '微信支付')
        add(days[20], '支出', 128, '山姆会员店-牛排', '生鲜', '购物', '微信支付')
        add(days[22], '支出', 68, '星巴克拿铁-大杯', '咖啡茶饮', '餐饮', '微信支付')
    if m == 11:
        add(days[6], '支出', 880, '大麦-演唱会门票', '演出', '娱乐', '支付宝',
            note='规则标注|疑似大额异常', account='支付宝余额')
        add(days[12], '支出', 39.9, '淘宝-秋冬拖鞋', '家居', '购物', '支付宝', account='支付宝余额')
        add(days[17], '支出', 42, '洗衣液-蓝月亮', '日化', '购物', '微信支付')
        add(days[23], '支出', 248, 'Keep会员年卡', '健身', '学习', '微信支付')

rows.sort(key=lambda r: (r['日期'], r['交易ID']))

OUT.mkdir(parents=True, exist_ok=True)
csv_path = OUT / 'D4_虚拟账单_2025年09-11月.csv'
with open(csv_path, 'w', encoding='utf-8-sig', newline='') as f:
    w = csv.DictWriter(f, fieldnames=['交易ID', '日期', '星期', '类型', '金额(元)', '描述',
                                      '二级分类', '一级分类', '账户', '支付方式', '备注'])
    w.writeheader()
    w.writerows(rows)

budget_path = OUT / 'D4_预算配置.csv'
budget = [
    ('餐饮', 2200, 90, '外卖、食堂、聚餐'),
    ('居住', 2700, 95, '房租+水电燃气'),
    ('交通', 260, 90, '地铁+共享单车'),
    ('通讯', 80, 100, '话费套餐'),
    ('购物', 800, 85, '数码/日用品'),
    ('衣着', 300, 90, '换季采购'),
    ('娱乐', 300, 85, '电影/会员/演出'),
    ('学习', 250, 100, '图书/课程'),
    ('医疗', 200, 100, '常备药/体检'),
    ('其他', 300, 100, '理发/快递/人情'),
]
with open(budget_path, 'w', encoding='utf-8-sig', newline='') as f:
    w = csv.writer(f)
    w.writerow(['一级分类', '月预算(元)', '预警线(%)', '说明'])
    w.writerows(budget)

print('已生成 %d 笔：%s' % (len(rows), csv_path.name))
print('预算配置：%s' % budget_path.name)
